import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { UserRegistration } from '../models/UserRegistrationRequest.model';
import { Role } from '../models/role';
import { jwtDecode } from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class Auth {
  private apiUrl = 'http://localhost:8080/api/auth';
  isLoggedIn: boolean = false;
  private userEmail: string | undefined;
  private userRole:any;

  private loggedInSubject = new BehaviorSubject<boolean>(this.isLoggedIn);

   // Public observable for components to subscribe to
  isLoggedIn$ = this.loggedInSubject.asObservable();


  constructor(private http: HttpClient) {
    this.getRole();
  }

  getToken(): string | null {
    const token = localStorage.getItem('token');
    if(token) {
      //changing the state of loggedIn state to true, if token is found
      this.loggedInSubject.next(true);
      return token;
    }
    return null;
  }

  getUserEmail(): string | undefined {
    return this.userEmail;
  }

  getRole(): string | null{
    const token = this.getToken();
    if(!token) {
      this.userEmail = undefined;
      this.loggedInSubject.next(false);
      this.userRole = null;
      return null;
    };

    try {
      const decoded = jwtDecode<any>(token);

      const roleString = decoded.role;
      this.userEmail = decoded.sub;
      if(roleString) {
        this.userRole = roleString;
        // console.log(this.userRole);
        this.loggedInSubject.next(true);
        // console.log(roleString);
        return this.userRole;
      }
      return null;
    }
    catch (e) {
      console.error("Failed to decode token. Token might be invalid or expired.", e);
      this.logout(); 
      return null;
    }
  }

  getUserRole(): string | null {
    return this.getRole();
  }

  setLoggedInState(token: string): void {
  localStorage.setItem('token', token); 
  
  try {
    const decoded = jwtDecode<any>(token);
    this.userEmail = decoded.sub; 

    this.loggedInSubject.next(true);
  } catch (e) {
    console.error("Failed to process token after login.", e);
    this.logout(); 
  }
}

  login(credentials: {email: string, password: string}): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, credentials);
  }

  register(data: UserRegistration): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`,data, {
      responseType: 'text'
    });
  }


  logout(): void {
    localStorage.removeItem('token');
    this.userEmail = undefined;
    this.loggedInSubject.next(false);
  }
  
}
