import { Component } from '@angular/core';
import { CreateHotel } from '../../hotel/create-hotel/hotel';
import { GetHotelByManager } from '../../hotel/get-hotel-by-manager/get-hotel-by-manager';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-home-manager',
  standalone: true,
  imports: [CreateHotel,GetHotelByManager,RouterModule],
  templateUrl: './home-manager.html',
  styleUrl: './home-manager.css'
})
export class HomeManager {

}
