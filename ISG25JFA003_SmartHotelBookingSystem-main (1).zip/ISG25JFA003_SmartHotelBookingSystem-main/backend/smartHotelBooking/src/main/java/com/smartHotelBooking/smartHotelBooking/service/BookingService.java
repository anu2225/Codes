package com.smartHotelBooking.smartHotelBooking.service;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.BookingRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingResponseDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingRoomResponseDTO;

import java.util.List;

public interface BookingService {

    void createBooking(BookingRequestDTO bookingRequest);

    BookingRoomResponseDTO getBookingById(long bookingId);

    List<BookingResponseDTO> getBookingsByUserId(long userId);

    void updateBooking(String bookingId, BookingRequestDTO updatedBooking);

    void cancelBooking(String bookingId);
}