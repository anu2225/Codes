package com.smartHotelBooking.smartHotelBooking.dto.responsedto;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class PaymentResponseDTO {
    private Long paymentId;
    private Long bookingId;
    private Double amount;
    private LocalDate paymentDate;
    private String paymentMethod;
    private String paymentStatus;
}
