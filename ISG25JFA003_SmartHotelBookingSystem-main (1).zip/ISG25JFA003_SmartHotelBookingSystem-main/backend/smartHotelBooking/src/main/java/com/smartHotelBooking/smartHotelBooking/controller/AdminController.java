package com.smartHotelBooking.smartHotelBooking.controller;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.UserRegistrationDTO;
import com.smartHotelBooking.smartHotelBooking.entity.User;
import com.smartHotelBooking.smartHotelBooking.service.impl.AdminServiceImpl;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@RequestMapping("/api/admin")
@RequiredArgsConstructor
@RestController
public class AdminController {

    private final AdminServiceImpl adminService;


    @PostMapping("/create-manager-account")
//    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> createManager(@Valid @RequestBody UserRegistrationDTO request) {
        adminService.createManager(request);
        return ResponseEntity.ok("Hotel Manager account created successfully!");
    }
    @PatchMapping("/user/{id}/status")
//    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> updateManagerStatus(@PathVariable int id, @RequestBody Map<String, Boolean> body) {
        boolean newStatus = body.get("active");
        adminService.updateUserStatus(Math.toIntExact(id), newStatus);
        return ResponseEntity.ok().build();
    }

}
