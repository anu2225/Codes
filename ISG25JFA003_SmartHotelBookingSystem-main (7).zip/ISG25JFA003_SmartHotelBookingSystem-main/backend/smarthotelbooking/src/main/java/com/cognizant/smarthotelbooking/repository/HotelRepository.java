package com.cognizant.smarthotelbooking.repository;

import com.cognizant.smarthotelbooking.entity.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface HotelRepository extends JpaRepository<Hotel, Long> {
    // useful custom queries you may want
    List<Hotel> findByLocationContainingIgnoreCase(String location);
    List<Hotel> findByRatingGreaterThanEqual(Double rating);
    List<Hotel> findByNameContainingIgnoreCase(String name);
    List<Hotel> findByAmenitiesContainingIgnoreCase(String amenity);

    List<Hotel> findByManagerId(long id);
}