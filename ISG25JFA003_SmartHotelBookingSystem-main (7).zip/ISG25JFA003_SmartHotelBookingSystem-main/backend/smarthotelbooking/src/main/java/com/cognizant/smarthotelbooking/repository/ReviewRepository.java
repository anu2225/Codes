package com.cognizant.smarthotelbooking.repository;

import com.cognizant.smarthotelbooking.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByHotel_HotelId(Long hotelId);

    List<Review> findByUser_UserId(Long userId);

}
