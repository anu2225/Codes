export interface ReviewPayload {
    hotelId: number;
    rating: number;
    comment: string;
}