import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function checkInBeforeCheckOutValidator(): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const checkInDate = group.get('checkInDate')?.value;
    const checkOutDate = group.get('checkOutDate')?.value;

    const checkIn = new Date(checkInDate);
    const checkOut = new Date(checkOutDate);

    return checkOut > checkIn ? null : { dateOrderInvalid: true };
  };
}
