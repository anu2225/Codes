package com.smartHotelBooking.smartHotelBooking.repository;

import com.smartHotelBooking.smartHotelBooking.entity.LoyaltyAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoyaltyAccountRepository extends JpaRepository<LoyaltyAccount, Long> {
    LoyaltyAccount findByUser_UserId(Long userId);
}
