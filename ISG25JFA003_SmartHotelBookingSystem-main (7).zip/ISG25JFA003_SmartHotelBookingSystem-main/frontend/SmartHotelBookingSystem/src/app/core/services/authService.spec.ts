import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { UserRegistration } from '../models/UserRegistrationRequest.model';
import { Auth } from './authService';

describe('Auth Service', () => {
  let service: Auth;
  let httpMock: HttpTestingController;

  const mockLoginResponse = {
    token: 'mock-jwt-token'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [Auth]
    });

    service = TestBed.inject(Auth);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
    localStorage.clear();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should login and return token', () => {
    const credentials = { email: 'test@example.com', password: 'password123' };

    service.login(credentials).subscribe(response => {
      expect(response.token).toEqual(mockLoginResponse.token);
    });

    const req = httpMock.expectOne('http://localhost:8080/api/auth/login');
    expect(req.request.method).toBe('POST');
    req.flush(mockLoginResponse);
  });

  it('should register a user and return text response', () => {
    const registrationData: UserRegistration = {
      email: 'newuser@example.com',
      password: 'newpassword',
      name: 'New User',
      contactNumber: '1284758349'
    };

    const mockResponse = 'User registered successfully';

    service.register(registrationData).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne('http://localhost:8080/api/auth/register');
    expect(req.request.method).toBe('POST');
    expect(req.request.responseType).toBe('text');
    req.flush(mockResponse);
  });
});
