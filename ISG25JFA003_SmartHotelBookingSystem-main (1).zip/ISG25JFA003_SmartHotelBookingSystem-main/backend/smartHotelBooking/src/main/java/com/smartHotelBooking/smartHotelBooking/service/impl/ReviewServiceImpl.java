package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.ReviewRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.ReviewResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.Hotel;
import com.smartHotelBooking.smartHotelBooking.entity.Review;
import com.smartHotelBooking.smartHotelBooking.entity.User;
import com.smartHotelBooking.smartHotelBooking.exception.BookingNotFoundException;
import com.smartHotelBooking.smartHotelBooking.repository.HotelRepository;
import com.smartHotelBooking.smartHotelBooking.repository.ReviewRepository;
import com.smartHotelBooking.smartHotelBooking.repository.UserRepository;
import com.smartHotelBooking.smartHotelBooking.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReviewServiceImpl implements ReviewService {


    @Autowired
    private UserRepository userRepository;

    @Autowired
    private HotelRepository hotelRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    @Override
    public ReviewResponseDTO createReview(ReviewRequestDTO dto) {
        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        User user = userRepository.findByEmail(email).orElseThrow(() ->
                new BookingNotFoundException("User not logged in")
        );
        Hotel hotel = hotelRepository.findById(dto.getHotelId()).orElseThrow();
        Review review = new Review();
        review.setRating(dto.getRating());
        review.setTimestamp(LocalDateTime.now());
        review.setComment(dto.getComment());
        review.setUser(user);
        review.setHotel(hotel);


        return new ReviewResponseDTO(reviewRepository.save(review));
    }


    @Override
    public List<ReviewResponseDTO> getReviewsByHotel(Long hotelId) {
        return reviewRepository.findByHotel_HotelId(hotelId)
                .stream()
                .map(ReviewResponseDTO::new)
                .collect(Collectors.toList());
    }

    @Override
    public List<ReviewResponseDTO> getReviewsByUser(Long userId) {
        return reviewRepository.findByUser_UserId(userId)
                .stream()
                .map(ReviewResponseDTO::new)
                .collect(Collectors.toList());
    }

    @Override
    public ReviewResponseDTO respondToReview(Long reviewId, String response) {
        Review review = reviewRepository.findById(reviewId).orElseThrow();
        review.setResponse(response);
        return new ReviewResponseDTO(reviewRepository.save(review));
    }

    @Override
    public ReviewResponseDTO updateResponse(Long reviewId, String response) {
        return respondToReview(reviewId, response);
    }

    @Override
    public void deleteReview(Long reviewId) {
        reviewRepository.deleteById(reviewId);
    }
}
