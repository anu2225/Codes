import { Component, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';
import { Route, RouterModule, RouterOutlet } from '@angular/router';
import { Router } from '@angular/router';
import { Auth } from '../../../core/services/authService';
import { Observable, Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule,MatToolbarModule, MatButtonModule,RouterOutlet,RouterModule,MatIconModule, MatMenuModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css'
})
export class Navbar implements OnInit{
  
  isLoggedIn$!: Observable<boolean>;
  userInitial: string = 'G';
  private authSubscription!: Subscription;
  id!:number;
  role:any;
  
  constructor(private authService: Auth, private router: Router) {
    this.role = this.authService.getUserRole();
  }

  ngOnInit(): void {
    this.isLoggedIn$ = this.authService.isLoggedIn$;
    this.authSubscription = this.isLoggedIn$.subscribe(isLoggedin => {
        if(isLoggedin) {
          const email = this.authService.getUserEmail();
          console.log("Email",  email);
          this.userInitial = email ? email.charAt(0).toUpperCase() : 'G';
        }else {
          this.userInitial = 'G';
        }
    })
  }


  logOut() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  myBookings() {
      this.router.navigate([`/bookings/user/${this.id}`]);
  }

  
  getHomeRoute(): string {
    switch (this.role) {
      case 'MANAGER':
        return '/home-manager';
      case 'ADMIN':
        return '/home-admin';
      default:
        return '/home';
    }
  }

  


}
