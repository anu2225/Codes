import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HotelService } from '../../../core/services/hotelService';
import { ActivatedRoute } from '@angular/router';
import { GetRoomsByHotelComponent } from '../../room/get-room-by-hotel-id/room';
import { GetAllReviewsHotel } from '../../review/get-all-reviews-hotel/get-all-reviews-hotel';
import { PostReview } from '../../review/post-review/post-review';
import { Auth } from '../../../core/services/authService';
import { CreateRoomComponent } from '../../room/create-room/room';

@Component({
  selector: 'app-get-hotel-by-id',
  standalone: true,
  imports: [CommonModule, FormsModule, GetRoomsByHotelComponent, GetAllReviewsHotel,PostReview, CreateRoomComponent],
  templateUrl: './hotel.html',
  styleUrls: ['./hotel.css']
})
export class GetHotelByIdComponent implements OnInit {
  role:any;
  hotelId!: number;
  hotel: any = null;
  errorMessage = '';

  constructor(private hotelService: HotelService, private route : ActivatedRoute, private authService: Auth) {
    this.role = this.authService.getRole();
  }


  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get("id");
      if(id) {
        this.hotelId = +id;
        this.getHotel();
      }
    })
  }

  getHotel() {
    if (!this.hotelId) {
      this.errorMessage = 'No ID Present';
      return;
    }
    this.hotelService.getHotelById(this.hotelId).subscribe({
      next: (data) => {
        this.hotel = data;
        this.errorMessage = '';
      },
      error: (err) => {
        this.hotel = null;
        this.errorMessage = 'Hotel not found or unauthorized!';
        console.error(err);
      }
    });
  }
}

