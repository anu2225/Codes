package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.PaymentRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.PaymentResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.*;
import com.smartHotelBooking.smartHotelBooking.entity.enums.Action;
import com.smartHotelBooking.smartHotelBooking.entity.enums.BookingStatus;
import com.smartHotelBooking.smartHotelBooking.entity.enums.PaymentStatus;
import com.smartHotelBooking.smartHotelBooking.exception.PaymentNotFoundException;
import com.smartHotelBooking.smartHotelBooking.repository.*;
import com.smartHotelBooking.smartHotelBooking.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;
    private final RoomRepository roomRepository;
    private final LoyaltyAccountRepository loyaltyAccountRepository;
    private final LoyaltyTransactionRepository loyaltyTransactionRepository;

//    public PaymentServiceImpl(PaymentRepository paymentRepository, BookingRepository bookingRepository) {
//        this.paymentRepository = paymentRepository;
//        this.bookingRepository = bookingRepository;
//    }

    @Override
    public void processPayment(PaymentRequestDTO dto) {
        Booking booking = bookingRepository.findById(dto.getBookingId())
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        Room room = roomRepository.findById(booking.getRoomId())
                .orElseThrow(() -> new RuntimeException("Room not found"));

        Payment payment = paymentRepository.findByBooking_BookingId(dto.getBookingId());
        if(payment == null) {
            throw new PaymentNotFoundException("Payment Request Not Found");
        }
        payment.setPaymentMethod(dto.getPaymentMethod());
        payment.setPaymentStatus(PaymentStatus.Success);
        booking.setStatus(BookingStatus.Confirmed);
        bookingRepository.save(booking);



        double price = room.getPrice();
        LocalDate checkInDate = booking.getCheckInDate();
        LocalDate checkOutDate = booking.getCheckOutDate();
        double finalPrice = price * checkInDate.until(checkOutDate, ChronoUnit.DAYS);
//
//        Payment payment = new Payment();
//        payment.setBooking(booking);
//        payment.setUser(booking.getUser());
//        payment.setAmount(finalPrice);
//        payment.setPaymentDate(LocalDate.now());
//        payment.setPaymentMethod(dto.getPaymentMethod());
//        payment.setPaymentStatus(PaymentStatus.Success);
//        paymentRepository.save(payment);
//



        int earnedPoints = (int) (finalPrice / 10);
        LoyaltyAccount account = loyaltyAccountRepository.findByUser_UserId(booking.getUser().getUserId());

        if (account == null) {
            account = new LoyaltyAccount();
            account.setUser(booking.getUser());
            account.setPointsBalance(earnedPoints);
            account.setLastUpdated(LocalDateTime.now());
        } else {
            account.setPointsBalance(account.getPointsBalance() + earnedPoints);
            account.setLastUpdated(LocalDateTime.now());
        }

        loyaltyAccountRepository.save(account);

        LoyaltyTransaction transaction = new LoyaltyTransaction(null, booking.getUser(), Action.EARN,
                "Earned points from payment", earnedPoints, LocalDateTime.now());
        loyaltyTransactionRepository.save(transaction);
    }


    @Override
    public PaymentResponseDTO getPaymentById(String paymentId) {
        Payment payment = paymentRepository.findById(Long.parseLong(paymentId))
                .orElseThrow(() -> new RuntimeException("Payment not found"));
        return mapToDTO(payment);
    }

    @Override
    public PaymentResponseDTO getPaymentByBookingId(String bookingId) {
        Long bookingIdLong = Long.parseLong(bookingId);
        return paymentRepository.findAll().stream()
                .filter(p -> p.getBooking().getBookingId().equals(bookingIdLong))
                .findFirst()
                .map(this::mapToDTO)
                .orElseThrow(() -> new RuntimeException("Payment not found for booking"));
    }

//    @Override
//    public void updatePayment(String paymentId, PaymentRequestDTO dto) {
//        Payment payment = paymentRepository.findById(Long.parseLong(paymentId))
//                .orElseThrow(() -> new RuntimeException("Payment not found"));
//
//        payment.setAmount(dto.getAmount());
//        payment.setPaymentDate();
//        payment.setPaymentMethod(dto.getPaymentMethod());
//        payment.setPaymentStatus(PaymentStatus.valueOf(dto.getPaymentStatus().toUpperCase()));
//
//        paymentRepository.save(payment);
//    }

    @Override
    public void deletePayment(String paymentId) {
        paymentRepository.deleteById(Long.parseLong(paymentId));
    }

    @Override
    public List<Payment> getAllPayments() {
        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        return paymentRepository.findPaymentsByUserEmail(email);
    }

    private PaymentResponseDTO mapToDTO(Payment payment) {
        PaymentResponseDTO dto = new PaymentResponseDTO();
        dto.setPaymentId(payment.getPaymentId());
        dto.setBookingId(payment.getBooking().getBookingId());
        dto.setAmount(payment.getAmount());
        dto.setPaymentDate(LocalDate.now());
        dto.setPaymentMethod(payment.getPaymentMethod());
        dto.setPaymentStatus(payment.getPaymentStatus().name());
        return dto;
    }
}