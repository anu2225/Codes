import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserRegistration } from '../models/UserRegistrationRequest.model';

@Injectable({
  providedIn: 'root'
})
export class User {
  private apiUrl = 'http://localhost:8080/api/user';

  constructor(private http: HttpClient) {}

  welcome(): Observable<any> {
    return this.http.get(`${this.apiUrl}/welcome-user`, {
      responseType: 'text'
    });
  }

  getAllUsers(): Observable<any> {
    return this.http.get(`${this.apiUrl}/users`);
  }

  getAllManagers(): Observable<any> {
    return this.http.get(`${this.apiUrl}/managers`);
  }

  
}
