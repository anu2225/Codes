package com.cognizant.smarthotelbooking.dto.responsedto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class LoyaltyResponseDTO {
    private Long userId;
    private int pointsBalance;
    private String message;
}
