package com.cognizant.smarthotelbooking.controller;


import com.cognizant.smarthotelbooking.dto.requestdto.AuthRequestDTO;
import com.cognizant.smarthotelbooking.dto.requestdto.UserRegistrationDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.AuthResponseDTO;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.repository.UserRepository;
import com.cognizant.smarthotelbooking.service.impl.UserServiceImpl;
import com.cognizant.smarthotelbooking.util.JwtUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {

    private final UserServiceImpl userService;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;

    @GetMapping("/welcome")
    public String welcome() {
        return "This route is working.";
    }

     @PostMapping("/register")
      public ResponseEntity<String> registerUser(@Valid @RequestBody UserRegistrationDTO userDto) {
                log.info("Registering user {}", userDto.getName());
                userService.registerUser(userDto);
                return ResponseEntity.ok("User registered Successfully");
      }

      @PostMapping("/login")
      public AuthResponseDTO authenticateAndGetToken(@RequestBody AuthRequestDTO authRequest) {
          Authentication authentication = authenticationManager.authenticate(
                  new UsernamePasswordAuthenticationToken(authRequest.getEmail(),authRequest.getPassword()));

                  if(authentication.isAuthenticated()) {
                      User user = userRepository.findByEmail(authRequest.getEmail())
                              .orElseThrow(() -> new BadCredentialsException("Invalid Credentials"));
                      log.info("Attempting to login...");
                      return new AuthResponseDTO(jwtUtil.generateToken(authRequest.getEmail(), user.getRole().name()));
                  }

          throw new BadCredentialsException("Authentication failed.");
      }
}
