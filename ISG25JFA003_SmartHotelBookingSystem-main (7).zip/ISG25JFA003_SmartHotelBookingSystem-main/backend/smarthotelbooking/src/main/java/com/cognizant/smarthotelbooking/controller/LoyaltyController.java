package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.LoyaltyRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyTransactionDTO;
import com.cognizant.smarthotelbooking.service.LoyaltyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/rewards")
@RequiredArgsConstructor
@Slf4j
public class LoyaltyController {

    private final LoyaltyService loyaltyService;

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/{userId}")
    public LoyaltyResponseDTO getPointsBalance(@PathVariable Long userId) {
        log.info("Fetching points");
        return loyaltyService.getPointsBalance(userId);
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/redeem")
    public LoyaltyResponseDTO redeemPoints(@RequestBody LoyaltyRequestDTO requestDTO) {
        return loyaltyService.redeemPoints(requestDTO);
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/history/{userId}")
    public List<LoyaltyTransactionDTO> getTransactionHistory(@PathVariable Long userId) {
        log.info("Getting Transaction History");
        return loyaltyService.getTransactionHistory(userId);
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/history/user")
    public List<LoyaltyTransactionDTO> getTransactionHistoryUser() {
        log.info("Getting Transaction History of current user");
        return loyaltyService.getTransactionHistoryUser();
    }

}