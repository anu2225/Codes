import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { UserResponse } from '../../../core/models/UserResponse.model';
import { User } from '../../../core/services/userService';

@Component({
  selector: 'app-get-all-managers',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './get-all-managers.html',
  styleUrl: './get-all-managers.css'
})
export class GetAllManagers {
  managers: UserResponse[] = [];
  isLoading: boolean = false; 
  
    constructor(private userService: User) {}
  
    getAllManagers() {
      this.isLoading = true;
      this.userService.getAllManagers().subscribe({
        next: (response: UserResponse[]) => {
          this.isLoading = false;
          this.managers = response;
        },
        error: (error) => {
          this.isLoading = false;
          console.error("Error fetching managers", error);
        }
      });
    }

}
