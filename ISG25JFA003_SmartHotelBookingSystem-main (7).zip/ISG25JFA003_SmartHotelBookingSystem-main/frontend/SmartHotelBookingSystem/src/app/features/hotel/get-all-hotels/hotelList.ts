export default class hotellist {
  hotelId!: number;
  name!: string;
  location!: string;
  amenities!: string;
  rating!: number;
  imageUrl!:string;
  managerId!: number;

  constructor(
    hotelId: number,
    name: string,
    location: string,
    amenities: string,
    rating: number,
    imageUrl:string,
    managerId: number
  ) {
    this.hotelId = hotelId;
    this.name = name;
    this.location = location;
    this.amenities = amenities;
    this.rating = rating;
    this.imageUrl = imageUrl;
    this.managerId = managerId;
  }
}