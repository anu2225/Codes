// manager.guard.ts
import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Role } from '../models/role';
import { Auth } from '../services/authService';

@Injectable({
  providedIn: 'root'
})
export class ManagerGuard implements CanActivate {
  constructor(private authService: Auth, private router: Router) {}

  canActivate(): boolean {
    const role = this.authService.getRole();
    console.log(role);
    if (role === Role.Manager) {
      return true;
    } else {
      this.router.navigate(['/login']);
      return false;
    }
  }
}