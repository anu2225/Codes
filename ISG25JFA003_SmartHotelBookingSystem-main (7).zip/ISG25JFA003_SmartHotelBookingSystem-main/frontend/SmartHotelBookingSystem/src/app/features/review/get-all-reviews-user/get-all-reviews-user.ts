import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ReviewService } from '../../../core/services/reviewService';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-get-all-reviews-user',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './get-all-reviews-user.html',
  styleUrl: './get-all-reviews-user.css'
})
export class GetAllReviewsUser implements OnInit{
   userId!: number;
   reviews: any[] = [];
   isLoading = false;
   error = '';
   
   constructor(private reviewService: ReviewService, private route: ActivatedRoute) {
    this.route.paramMap.subscribe(params => {
      const id = params.get("id");
      if(id) {
        this.userId = +id;
        console.log(this.userId);
      }
    });
   }
   
   ngOnInit(): void {
     this.getAllReviews();
   }

   getAllReviews() {
    this.isLoading = true;
      this.reviewService.getAllReviewsUser(this.userId).subscribe({
        next: (data) => {
          this.isLoading = false;
          this.reviews = data;
        },
        error: (err) => {
          this.error = err.error;
          this.isLoading = false;
        }
      })
   }
}
