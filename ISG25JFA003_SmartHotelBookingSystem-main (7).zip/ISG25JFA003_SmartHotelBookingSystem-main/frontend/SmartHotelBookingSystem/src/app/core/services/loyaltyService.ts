import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoyaltyPayload } from '../models/loyalty.model';


@Injectable({
  providedIn: 'root'
})

export class LoyaltyService {
  private apiUrl = 'http://localhost:8080/api';
  constructor(private http: HttpClient) {}

  getRewardHistory(): Observable<any> {
    const url = `${this.apiUrl}/rewards/history/user`;
    return this.http.get<any>(url);
  }

  getRewardDetails(userId: number): Observable<any> {
    const url = `${this.apiUrl}/rewards/${userId}`;
    return this.http.get<any>(url);
  }

  redeemRewards(loyaltyPayload: LoyaltyPayload): Observable<any> {
    const url = `${this.apiUrl}/rewards/redeem`;
    return this.http.post<any>(url, loyaltyPayload);
  }
}