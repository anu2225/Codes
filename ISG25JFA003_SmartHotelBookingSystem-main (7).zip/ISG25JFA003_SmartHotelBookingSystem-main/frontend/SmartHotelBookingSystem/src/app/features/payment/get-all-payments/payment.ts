import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { PaymentService } from '../../../core/services/paymentservice';

@Component({
  selector: 'app-get-all-payments',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './payment.html',
  styleUrls: ['./payment.css']
})
export class GetAllPayments implements OnInit {
  payments: any[] = [];

  // constructor(private http: HttpClient) {
  //   this.http.get<any[]>('http://localhost:8080/api/payments/get-payments')
  //     .subscribe({
  //       next: res => this.payments = res,
  //       error: err => alert('❌ Failed to load payments')
  //     });
  constructor(private paymentService: PaymentService) {}

  ngOnInit(): void {
     this.paymentService.getAllPayments().subscribe({
      next: (data) => {
        this.payments = data;
        console.log(data);
      },
      error: (err) => {
        alert("Error fetching data" + err);
        console.error(err);
      }
     });
  }
  }
