
import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Role } from '../models/role';
import { Auth } from '../services/authService';

@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {
  constructor(private authService: Auth, private router: Router) {}

  canActivate(): boolean {
    const role = this.authService.getRole();
    if (role === Role.Admin) {
      return true;
    } else {
      this.router.navigate(['/login']);
      return false;
    }
  }
}
