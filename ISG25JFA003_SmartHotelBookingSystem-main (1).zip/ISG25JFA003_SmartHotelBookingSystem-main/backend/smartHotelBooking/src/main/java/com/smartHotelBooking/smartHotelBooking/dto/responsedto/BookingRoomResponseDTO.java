package com.smartHotelBooking.smartHotelBooking.dto.responsedto;

import com.smartHotelBooking.smartHotelBooking.entity.enums.BookingStatus;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;

@Data
@AllArgsConstructor
public class BookingRoomResponseDTO {
    private Long bookingId;
    private Long userId;
    private String name;
    private Long roomId;
    private String roomType;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private LocalDate bookingDate;
    private BookingStatus status;
}
