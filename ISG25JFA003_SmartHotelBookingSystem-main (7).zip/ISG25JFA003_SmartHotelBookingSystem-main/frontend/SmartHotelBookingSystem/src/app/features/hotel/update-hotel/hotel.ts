import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HotelService } from '../../../core/services/hotelService';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-hotel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './hotel.html',
  styleUrls: ['./hotel.css']
})
export class UpdateHotelComponent {
  hotelId!: number;
  hotel: any = null;
  message = '';
  errorMessage = '';

  constructor(private hotelService: HotelService, private router: Router, private route: ActivatedRoute) {
    this.route.paramMap.subscribe(params => {
      const id = params.get("hotelId");
      if(id) {
        console.log(id);
        this.hotelId = +id;
        this.getHotelById();
      }
    })
  }

  // Step 1: Get Hotel by ID first
  getHotelById() {
    if (!this.hotelId) {
      this.errorMessage = 'Enter a valid Hotel ID!';
      return;
    }

    this.hotelService.getHotelById(this.hotelId).subscribe({
      next: (data) => {
        this.hotel = data;
        console.log(data);
        this.message = '';
        this.errorMessage = '';
      },
      error: (err) => {
        this.hotel = null;
        this.errorMessage = 'Hotel not found or unauthorized!';
        console.error(err);
      }
    });
  }

  // Step 2: Update Hotel
  updateHotel() {
    if (!this.hotel) {
      this.errorMessage = 'No hotel data to update!';
      return;
    }

    this.hotelService.updateHotel(this.hotelId, this.hotel).subscribe({
      next: () => {
        this.message = 'Hotel updated successfully!';
        this.errorMessage = '';
        this.router.navigate(["/home-manager"]);
      },
      error: (err) => {
        this.message = '';
        this.errorMessage = 'Failed to update hotel!';
        console.error(err);
      }
    });
  }
}
