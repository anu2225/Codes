import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  private baseUrl = 'http://localhost:8080/api/payments';

  constructor(private http: HttpClient) {}

  processPayment(paymentData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/process`, paymentData);
  }

  getAllPayments(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/get-payments`);
  }

  getPaymentById(paymentId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${paymentId}`);
  }

  getPaymentByBookingId(bookingId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/booking/${bookingId}`);
  }
}

