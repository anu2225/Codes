import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { ReviewService } from '../../../core/services/reviewService';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Auth } from '../../../core/services/authService';

@Component({
  selector: 'app-get-all-reviews-hotel',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './get-all-reviews-hotel.html',
  styleUrl: './get-all-reviews-hotel.css'
})
export class GetAllReviewsHotel implements OnInit{
   role: any; 
   responseForm!:FormGroup;
   @Input() hotelId!:number;
   reviews: any[] = [];
   isLoading = false;
   error = '';


   constructor(private reviewService: ReviewService, private fb: FormBuilder, private authService: Auth) {}

   ngOnInit(): void {
     this.role = this.authService.getRole();
     this.getReviews();

     this.responseForm = this.fb.group({
        response: ['',[Validators.required]]
     })
   }

   getReviews() {
    this.isLoading = true;
    this.reviewService.getAllReviewsHotel(this.hotelId).subscribe({
      next: (data) => {
        this.isLoading = false;
        this.reviews = data;
      },
      error: (err) => {
        this.reviews = [];
        this.error = err;
        this.isLoading = false;
      }
    })
   }

   deleteReview(reviewId: number): void {
    this.reviewService.deleteReview(reviewId).subscribe({
      next: () => {
        this.getReviews();
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  submitResponse(reviewId: number): void {
    console.log(this.responseForm.value);
    // const responseBody = this.responseForm[reviewId].value;
    this.reviewService.reviewResponse(reviewId,this.responseForm.value).subscribe( {
      next: (data) => {
        console.log(data);
        this.getReviews();
      },
      error: (err) => {
        console.error(err);
      }
    }
    //   () => {
    //   this.getReviews();
    // }
    
  );
  }
}