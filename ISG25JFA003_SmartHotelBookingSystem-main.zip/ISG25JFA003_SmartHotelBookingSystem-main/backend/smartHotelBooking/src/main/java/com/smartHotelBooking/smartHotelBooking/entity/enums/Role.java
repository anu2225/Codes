package com.smartHotelBooking.smartHotelBooking.entity.enums;

public enum Role {
    ADMIN,
    MANAGER,
    USER
}