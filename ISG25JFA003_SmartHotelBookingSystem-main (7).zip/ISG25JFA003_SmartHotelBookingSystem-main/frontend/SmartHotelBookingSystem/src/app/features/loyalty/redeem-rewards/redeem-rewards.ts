import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { LoyaltyService } from '../../../core/services/loyaltyService';

@Component({
  selector: 'app-redeem-rewards',
  imports: [CommonModule],
  templateUrl: './redeem-rewards.html',
  styleUrl: './redeem-rewards.css'
})
export class RedeemRewards {
  constructor(private loyaltyService: LoyaltyService) {}

  
}
