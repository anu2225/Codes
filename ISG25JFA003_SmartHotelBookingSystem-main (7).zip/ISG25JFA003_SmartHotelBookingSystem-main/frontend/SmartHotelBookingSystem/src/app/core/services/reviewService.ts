import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ReviewPayload } from '../models/review.model';

@Injectable({
    providedIn: 'root'
})

export class ReviewService {

    private apiUrl = 'http://localhost:8080/api/reviews';

    constructor(private http: HttpClient) { }

    postReview(review: ReviewPayload): Observable<any> {
        return this.http.post<any>(this.apiUrl, review);
    }

    getAllReviewsHotel(hotelId: number): Observable<any> {
        const url = `${this.apiUrl}/hotel/${hotelId}`;
        return this.http.get<any>(url);
    }

    getAllReviewsUser(userId: number): Observable<any> {
        const url = `${this.apiUrl}/user/${userId}`;
        return this.http.get<any>(url);
    }
    deleteReview(reviewId: number): Observable<any> {
        const url = `${this.apiUrl}/${reviewId}`;
        return this.http.delete<any>(url, {
            responseType: 'text' as 'json'
        });
    }
    reviewResponse(reviewId: number, responseBody: any): Observable<any> {
        const url = `${this.apiUrl}/${reviewId}/response`;
        return this.http.patch<any>(url, responseBody);
    }
}