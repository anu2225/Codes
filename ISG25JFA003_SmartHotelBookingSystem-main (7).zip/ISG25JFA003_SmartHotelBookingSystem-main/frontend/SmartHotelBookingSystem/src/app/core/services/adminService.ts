import { Injectable } from '@angular/core';
import { UserRegistration } from '../models/UserRegistrationRequest.model';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = "http://localhost:8080/api/admin";

  constructor(private http: HttpClient) {}

  createManager(data: UserRegistration): Observable<any> {
      return this.http.post(`${this.apiUrl}/create-manager-account`,data, {
        responseType: 'text'
      });
   }
  
}
