import { Role } from "./role"

export interface UserResponse {
    userId: number,
    name: string,
    email: string,
    role: Role,
    contactNumber: string
}