package com.cognizant.smarthotelbooking.dto.responsedto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HotelResponseDTO {
    private Long hotelId;
    private String name;
    private String location;
    private String amenities;
    private Double rating;
    private String imageUrl;
    private long managerId;
}