package com.cognizant.smarthotelbooking.service.impl;

import com.cognizant.smarthotelbooking.dto.requestdto.LoyaltyRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyTransactionDTO;
import com.cognizant.smarthotelbooking.entity.*;
import com.cognizant.smarthotelbooking.exception.InvalidPointsException;
import com.cognizant.smarthotelbooking.repository.*;
import com.cognizant.smarthotelbooking.entity.enums.Action;
import com.cognizant.smarthotelbooking.entity.enums.BookingStatus;
import com.cognizant.smarthotelbooking.exception.BookingNotFoundException;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import com.cognizant.smarthotelbooking.service.LoyaltyService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class LoyaltyServiceImpl implements LoyaltyService {

    private final LoyaltyAccountRepository loyaltyAccountRepository;
    private final LoyaltyTransactionRepository loyaltyTransactionRepository;
    private final RedemptionRepository redemptionRepository;
    private final UserRepository userRepository;
    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;

    @Override
    public LoyaltyResponseDTO getPointsBalance(Long userId) {
        LoyaltyAccount account = loyaltyAccountRepository.findByUser_UserId(userId);
        return new LoyaltyResponseDTO(userId, account.getPointsBalance(), "Points fetched successfully");
    }

    @Transactional
    @Override
    public LoyaltyResponseDTO redeemPoints(LoyaltyRequestDTO requestDTO) {
        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new UserNotFoundException("No User Found"));
        LoyaltyAccount account = loyaltyAccountRepository.findByUser_UserId(user.getUserId());

        if (account == null) {

            account = new LoyaltyAccount();
            account.setUser(user);
            account.setPointsBalance(0);
            account.setLastUpdated(LocalDateTime.now());
            loyaltyAccountRepository.save(account);
            throw new IllegalArgumentException("Invalid arguments: Account not found, Created automatically");
        }

        if (account.getPointsBalance() < requestDTO.getPoints()) {
            throw new InvalidPointsException("Insufficient points");
        }



        Booking booking = bookingRepository.findById(requestDTO.getBookingId())
                .orElseThrow(() -> new BookingNotFoundException("Booking not found"));


        
        Payment payment = paymentRepository.findByBooking_BookingId(requestDTO.getBookingId());
        double newAmount = payment.getAmount() - requestDTO.getPoints();

        if (newAmount < 0) {
            throw new InvalidPointsException("Redeemed points exceed payment amount");
        }

        account.setPointsBalance(account.getPointsBalance() - requestDTO.getPoints());
        account.setLastUpdated(LocalDateTime.now());
        loyaltyAccountRepository.save(account);

//        booking.setStatus(BookingStatus.CONFIRMED);
        bookingRepository.save(booking);

        payment.setAmount(newAmount);
//        payment.setPaymentMethod("Loyalty Points");
        paymentRepository.save(payment);

        Redemption redemption = new Redemption(null, user.getUserId(), requestDTO.getBookingId(),
                requestDTO.getPoints(), newAmount);
        redemptionRepository.save(redemption);

        LoyaltyTransaction transaction = new LoyaltyTransaction(null, account.getUser(), Action.REDEEM,
                "Redeemed points for booking", requestDTO.getPoints(), LocalDateTime.now());
        loyaltyTransactionRepository.save(transaction);

        return new LoyaltyResponseDTO(user.getUserId(), account.getPointsBalance(), "Points redeemed successfully");
    }

    @Override
    public List<LoyaltyTransactionDTO> getTransactionHistoryUser() {

        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();

        // Fetch the user entity
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found"));

        // Fetch transactions by user ID
        List<LoyaltyTransaction> transactions = loyaltyTransactionRepository.findByUser_UserId(user.getUserId());

        // Map to DTOs
        return transactions.stream().map(tx -> {
            LoyaltyTransactionDTO dto = new LoyaltyTransactionDTO();
            dto.setAction(tx.getAction());
            dto.setDescription(tx.getDescription());
            dto.setPoints(tx.getPoints());
            dto.setTimestamp(tx.getTimestamp());
            return dto;
        }).collect(Collectors.toList());
    }

    public List<LoyaltyTransactionDTO> getTransactionHistory(Long userId) {
        List<LoyaltyTransaction> transactions = loyaltyTransactionRepository.findByUser_UserId(userId);
        return transactions.stream().map(tx -> {
            LoyaltyTransactionDTO dto = new LoyaltyTransactionDTO();
            dto.setAction(tx.getAction());
            dto.setDescription(tx.getDescription());
            dto.setPoints(tx.getPoints());
            dto.setTimestamp(tx.getTimestamp());
            return dto;
        }).collect(Collectors.toList());
    }


    @Override
    public LoyaltyResponseDTO earnPoints(LoyaltyRequestDTO requestDTO) {  //This function is not needed as it is used in paymentProcess function
        LoyaltyAccount account = loyaltyAccountRepository.findByUser_UserId(requestDTO.getUserId());
        int earnedPoints = (int) (requestDTO.getAmount() * 0.1); // 10% of amount

        account.setPointsBalance(account.getPointsBalance() + earnedPoints);
        account.setLastUpdated(LocalDateTime.now());
        loyaltyAccountRepository.save(account);

        LoyaltyTransaction transaction = new LoyaltyTransaction(null, account.getUser(), Action.EARN,
                "Earned points from booking", earnedPoints, LocalDateTime.now());
        loyaltyTransactionRepository.save(transaction);

        return new LoyaltyResponseDTO(requestDTO.getUserId(), account.getPointsBalance(), "Points earned successfully");
    }

    @Override
    public LoyaltyResponseDTO applyPointsToBooking(LoyaltyRequestDTO requestDTO) {   //This function is also not needed
        LoyaltyAccount account = loyaltyAccountRepository.findByUser_UserId(requestDTO.getUserId());
        if (account.getPointsBalance() < requestDTO.getPoints()) {
            return new LoyaltyResponseDTO(requestDTO.getUserId(), account.getPointsBalance(), "Insufficient points to apply");
        }

        account.setPointsBalance(account.getPointsBalance() - requestDTO.getPoints());
        account.setLastUpdated(LocalDateTime.now());
        loyaltyAccountRepository.save(account);

        LoyaltyTransaction transaction = new LoyaltyTransaction(null, account.getUser(), Action.REDEEM,
                "Applied points to booking", requestDTO.getPoints(), LocalDateTime.now());
        loyaltyTransactionRepository.save(transaction);

        return new LoyaltyResponseDTO(requestDTO.getUserId(), account.getPointsBalance(), "Points applied successfully");
    }
}
