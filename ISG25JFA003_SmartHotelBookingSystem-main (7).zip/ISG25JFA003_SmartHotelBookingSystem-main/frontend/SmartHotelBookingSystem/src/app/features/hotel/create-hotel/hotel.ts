import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HotelService } from '../../../core/services/hotelService';

@Component({
  selector: 'app-create-hotel',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './hotel.html',
  styleUrls: ['./hotel.css']
})
export class CreateHotel {
  hotelForm: FormGroup;
  message = '';

  constructor(private fb: FormBuilder, private hotelService: HotelService, private router: Router) {
    this.hotelForm = this.fb.group({
      name: ['', Validators.required],
      location: ['', Validators.required],
      amenities: ['', Validators.required],
      rating: [null, [Validators.required, Validators.max(5)]],
      imageUrl: ['', [Validators.required]]
    });
  }

  onSubmit() {
    if (this.hotelForm.invalid) {
      this.message = 'Please fill all fields correctly!';
      return;
    }

    const token = localStorage.getItem('token') || '';
    this.hotelService.createHotel(this.hotelForm.value, token).subscribe({
      next: (res) => {
        this.message = 'Hotel created successfully!';
        this.router.navigate(['/home-manager']);
      },
      error: (err) => {
        console.error(err);
        this.message = 'Something went wrong while creating hotel!';
      }
    });
  }
}

