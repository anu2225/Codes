import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { LoyaltyService } from '../../../core/services/loyaltyService';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-reward-history',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './reward-history.html',
  styleUrl: './reward-history.css'
})
export class RewardHistory implements OnInit{
  rewardHistory: any[] = [];
  error = '';
  
  constructor(private loyaltyService: LoyaltyService, private route: ActivatedRoute) {
    // this.route.paramMap.subscribe(params => {
    //   const id = params.get("id");
    //   if(id) {
    //     this.userId = +id;
    //     console.log(this.userId);
    //   }
    // });
  }

  ngOnInit(): void {
    this.loyaltyService.getRewardHistory().subscribe({
      next: (data) => {
        this.rewardHistory = data;
      },
      error: (err) => {
        this.error = "Error Fetching Data", err;
      }
    });
  }
}
