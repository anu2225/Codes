import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-get-payment-by-booking',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './payment.html',
  styleUrls: ['./payment.css']
})
export class GetPaymentByBooking {
  form: FormGroup;
  payment: any = null;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.form = this.fb.group({
      bookingId: ['', Validators.required]
    });
  }

  fetchPayment() {
    if (this.form.valid) {
      this.http.get(`http://localhost:8080/api/payments/booking/${this.form.value.bookingId}`)
        .subscribe({
          next: res => this.payment = res,
          error: () => alert('❌ Payment not found for booking')
        });
    }
  }
}
