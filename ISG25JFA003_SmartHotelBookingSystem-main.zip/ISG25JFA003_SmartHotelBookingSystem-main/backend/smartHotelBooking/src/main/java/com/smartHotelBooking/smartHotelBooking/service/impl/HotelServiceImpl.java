
package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.HotelRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.HotelResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.Hotel;
import com.smartHotelBooking.smartHotelBooking.repository.HotelRepository;
import com.smartHotelBooking.smartHotelBooking.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class HotelServiceImpl implements HotelService {

    private final HotelRepository hotelRepository;

    @Autowired
    public HotelServiceImpl(HotelRepository hotelRepository) {
        this.hotelRepository = hotelRepository;
    }

    @Override
    public HotelResponseDTO createHotel(HotelRequestDTO dto) {
        Hotel hotel = new Hotel();
        hotel.setName(dto.getName());
        hotel.setLocation(dto.getLocation());
        hotel.setAmenities(dto.getAmenities());
        hotel.setRating(dto.getRating());
        hotel.setManagerId(dto.getManagerId());
        Hotel saved = hotelRepository.save(hotel);
        return mapToDTO(saved);
    }

    @Override
    public HotelResponseDTO updateHotel(Long id, HotelRequestDTO dto) {
        Hotel hotel = hotelRepository.findById(id).orElseThrow(() -> new RuntimeException("Hotel not found"));
        hotel.setName(dto.getName());
        hotel.setLocation(dto.getLocation());
        hotel.setAmenities(dto.getAmenities());
        hotel.setRating(dto.getRating());
        hotel.setManagerId(dto.getManagerId());
        Hotel updated = hotelRepository.save(hotel);
        return mapToDTO(updated);
    }

    @Override
    public void deleteHotel(Long id) {
        hotelRepository.deleteById(id);
    }

    @Override
    public HotelResponseDTO getHotelById(Long id) {
        Hotel hotel = hotelRepository.findById(id).orElseThrow(() -> new RuntimeException("Hotel not found"));
        return mapToDTO(hotel);
    }

    @Override
    public List<HotelResponseDTO> getAllHotels() {
        return hotelRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Override
    public List<HotelResponseDTO> searchByLocation(String location) {
        return hotelRepository.findByLocationContainingIgnoreCase(location)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Override
    public List<HotelResponseDTO> filterByRating(Double minRating) {
        return hotelRepository.findByRatingGreaterThanEqual(minRating)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    private HotelResponseDTO mapToDTO(Hotel h) {
        return new HotelResponseDTO(h.getHotelId(), h.getName(), h.getLocation(), h.getAmenities(), h.getRating(), h.getManagerId());
    }
}
