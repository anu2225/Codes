export interface UserRegistration {
    name:string,
    email:string,
    password:string,
    contactNumber:string
}