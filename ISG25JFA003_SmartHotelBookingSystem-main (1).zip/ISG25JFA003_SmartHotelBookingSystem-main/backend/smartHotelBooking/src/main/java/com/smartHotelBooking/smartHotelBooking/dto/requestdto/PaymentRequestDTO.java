package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class PaymentRequestDTO {
    private Long bookingId;
    private Double amount;
    private LocalDate paymentDate;
    @NotBlank(message = "Payment Method should not be blank")
    private String paymentMethod;
    private String paymentStatus;
}
