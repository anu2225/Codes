package com.cognizant.smarthotelbooking.dto.responsedto;

import lombok.Data;

@Data
public class ReviewUpdateDTO {
    private String response;
}
