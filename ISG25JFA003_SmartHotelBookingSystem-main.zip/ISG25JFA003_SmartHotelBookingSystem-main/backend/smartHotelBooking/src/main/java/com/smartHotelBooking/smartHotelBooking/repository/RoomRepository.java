package com.smartHotelBooking.smartHotelBooking.repository;

import com.smartHotelBooking.smartHotelBooking.entity.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoomRepository extends JpaRepository<Room, Long> {

    // Find all rooms for a given hotel
    List<Room> findByHotel_HotelId(Long hotelId);

    // Find rooms cheaper than a given price
    List<Room> findByPriceBetween(Double minPrice, Double maxPrice);

    // Find all available rooms
    List<Room> findByAvailabilityTrue();
}

