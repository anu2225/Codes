package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.LoyaltyRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.LoyaltyResponseDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.LoyaltyTransactionDTO;
import com.smartHotelBooking.smartHotelBooking.entity.*;
import com.smartHotelBooking.smartHotelBooking.entity.enums.Action;
import com.smartHotelBooking.smartHotelBooking.entity.enums.BookingStatus;
import com.smartHotelBooking.smartHotelBooking.exception.UserNotFoundException;
import com.smartHotelBooking.smartHotelBooking.repository.*;
import com.smartHotelBooking.smartHotelBooking.service.LoyaltyService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class LoyaltyServiceImpl implements LoyaltyService {

    @Autowired
    private LoyaltyAccountRepository loyaltyAccountRepository;

    @Autowired
    private LoyaltyTransactionRepository loyaltyTransactionRepository;

    @Autowired
    private RedemptionRepository redemptionRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Override
    public LoyaltyResponseDTO getPointsBalance(Long userId) {
        LoyaltyAccount account = loyaltyAccountRepository.findByUser_UserId(userId);
        return new LoyaltyResponseDTO(userId, account.getPointsBalance(), "Points fetched successfully");
    }

    @Transactional
    @Override
    public LoyaltyResponseDTO redeemPoints(LoyaltyRequestDTO requestDTO) {
        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new UserNotFoundException("No User Found"));
        LoyaltyAccount account = loyaltyAccountRepository.findByUser_UserId(user.getUserId());

        if (account == null) {
//            User user = userRepository.findById(Math.toIntExact(requestDTO.getUserId()))
//                    .orElseThrow(() -> new IllegalArgumentException("User not found"));

            account = new LoyaltyAccount();
            account.setUser(user);
            account.setPointsBalance(0);
            account.setLastUpdated(LocalDateTime.now());
            loyaltyAccountRepository.save(account);
            throw new IllegalArgumentException("Invalid arguments: Account not found, Created automatically");
        }

        if (account.getPointsBalance() < requestDTO.getPoints()) {
            throw new IllegalArgumentException("Invalid arguments: Insufficient points");
        }

        account.setPointsBalance(account.getPointsBalance() - requestDTO.getPoints());
        account.setLastUpdated(LocalDateTime.now());
        loyaltyAccountRepository.save(account);

        Booking booking = bookingRepository.findById(requestDTO.getBookingId())
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
        booking.setStatus(BookingStatus.Confirmed);
        bookingRepository.save(booking);

        Payment payment = paymentRepository.findByBooking_BookingId(requestDTO.getBookingId());
        double newAmount = payment.getAmount() - requestDTO.getPoints();
        payment.setAmount(newAmount);
        paymentRepository.save(payment);

        Redemption redemption = new Redemption(null, user.getUserId(), requestDTO.getBookingId(),
                requestDTO.getPoints(), newAmount);
        redemptionRepository.save(redemption);

        LoyaltyTransaction transaction = new LoyaltyTransaction(null, account.getUser(), Action.REDEEM,
                "Redeemed points for booking", requestDTO.getPoints(), LocalDateTime.now());
        loyaltyTransactionRepository.save(transaction);

        return new LoyaltyResponseDTO(user.getUserId(), account.getPointsBalance(), "Points redeemed successfully");
    }

    @Override
    public List<LoyaltyTransactionDTO> getTransactionHistory(Long userId) {
        List<LoyaltyTransaction> transactions = loyaltyTransactionRepository.findByUser_UserId(userId);
        return transactions.stream().map(tx -> {
            LoyaltyTransactionDTO dto = new LoyaltyTransactionDTO();
            dto.setAction(tx.getAction());
            dto.setDescription(tx.getDescription());
            dto.setPoints(tx.getPoints());
            dto.setTimestamp(tx.getTimestamp());
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public LoyaltyResponseDTO earnPoints(LoyaltyRequestDTO requestDTO) {
        LoyaltyAccount account = loyaltyAccountRepository.findByUser_UserId(requestDTO.getUserId());
        int earnedPoints = (int) (requestDTO.getAmount() * 0.1); // 10% of amount

        account.setPointsBalance(account.getPointsBalance() + earnedPoints);
        account.setLastUpdated(LocalDateTime.now());
        loyaltyAccountRepository.save(account);

        LoyaltyTransaction transaction = new LoyaltyTransaction(null, account.getUser(), Action.EARN,
                "Earned points from booking", earnedPoints, LocalDateTime.now());
        loyaltyTransactionRepository.save(transaction);

        return new LoyaltyResponseDTO(requestDTO.getUserId(), account.getPointsBalance(), "Points earned successfully");
    }

    @Override
    public LoyaltyResponseDTO applyPointsToBooking(LoyaltyRequestDTO requestDTO) {
        LoyaltyAccount account = loyaltyAccountRepository.findByUser_UserId(requestDTO.getUserId());
        if (account.getPointsBalance() < requestDTO.getPoints()) {
            return new LoyaltyResponseDTO(requestDTO.getUserId(), account.getPointsBalance(), "Insufficient points to apply");
        }

        account.setPointsBalance(account.getPointsBalance() - requestDTO.getPoints());
        account.setLastUpdated(LocalDateTime.now());
        loyaltyAccountRepository.save(account);

        LoyaltyTransaction transaction = new LoyaltyTransaction(null, account.getUser(), Action.REDEEM,
                "Applied points to booking", requestDTO.getPoints(), LocalDateTime.now());
        loyaltyTransactionRepository.save(transaction);

        return new LoyaltyResponseDTO(requestDTO.getUserId(), account.getPointsBalance(), "Points applied successfully");
    }
}
