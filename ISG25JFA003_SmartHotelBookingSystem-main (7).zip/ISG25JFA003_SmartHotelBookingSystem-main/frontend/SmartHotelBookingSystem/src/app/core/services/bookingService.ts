import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private apiUrl = 'http://localhost:8080/api/bookings';

  constructor(private http: HttpClient ) {}

  createBooking(bookingData: {roomId:number,checkInDate:Date,checkOutDate:Date}):Observable<any> {
      return this.http.post(`${this.apiUrl}/create`,bookingData);
  }

  getAllBookings():Observable<any> {
    return this.http.get(`${this.apiUrl}`);
  }

  getBooking(id:number):Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  getBookingsByUser():Observable<any> {
    return this.http.get(`${this.apiUrl}/user`);
  }

  getBookingByUser(userId:number):Observable<any> {
    return this.http.get(`${this.apiUrl}/user/${userId}`)
  }

  deleteBooking(bookingId: number):Observable<any> {
    return this.http.delete(`${this.apiUrl}/${bookingId}`, {
      responseType: 'text'
    })
  }

}
