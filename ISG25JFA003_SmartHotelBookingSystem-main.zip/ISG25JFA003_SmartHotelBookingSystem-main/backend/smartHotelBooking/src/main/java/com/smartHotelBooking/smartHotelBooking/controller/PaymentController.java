package com.smartHotelBooking.smartHotelBooking.controller;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.PaymentRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.PaymentResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.Payment;
import com.smartHotelBooking.smartHotelBooking.service.PaymentService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@Slf4j
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/process")
    public ResponseEntity<String> processPayment(@Valid @RequestBody PaymentRequestDTO paymentRequest) {
        log.info("Processing payment for booking ID: {}", paymentRequest.getBookingId());
        paymentService.processPayment(paymentRequest);
        return ResponseEntity.ok("Payment processed successfully.");
    }

    @GetMapping("/getPayments")
    public ResponseEntity<List<Payment>> getAllPayments() {
        return ResponseEntity.ok(paymentService.getAllPayments());
    }

    @GetMapping("/{paymentId}")
    public ResponseEntity<PaymentResponseDTO> getPayment(@PathVariable String paymentId) {
        log.info("Fetching payment with ID: {}", paymentId);
        PaymentResponseDTO payment = paymentService.getPaymentById(paymentId);
        return ResponseEntity.ok(payment);
    }

    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<PaymentResponseDTO> getPaymentByBooking(@PathVariable String bookingId) {
        log.info("Fetching payment for booking ID: {}", bookingId);
        PaymentResponseDTO payment = paymentService.getPaymentByBookingId(bookingId);
        return ResponseEntity.ok(payment);
    }

    @PutMapping("/{paymentId}")
    public ResponseEntity<String> updatePayment(@PathVariable String paymentId,
                                                @Valid @RequestBody PaymentRequestDTO updatedPayment) {
        log.info("Updating payment ID: {}", paymentId);
        paymentService.updatePayment(paymentId, updatedPayment);
        return ResponseEntity.ok("Payment updated successfully.");
    }

    @DeleteMapping("/{paymentId}")
    public ResponseEntity<String> deletePayment(@PathVariable String paymentId) {
        log.info("Deleting payment ID: {}", paymentId);
        paymentService.deletePayment(paymentId);
        return ResponseEntity.ok("Payment deleted successfully.");
    }
}