import { Component } from '@angular/core';
import { AdminService } from '../../../core/services/adminService';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-manager-account',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule,MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './create-manager-account.html',
  styleUrl: './create-manager-account.css'
})
export class CreateManagerAccount {
  managerForm:FormGroup;
  submitted = false;

  constructor(private adminService: AdminService, private fbuilder:FormBuilder, private router: Router) {
      this.managerForm = this.fbuilder.group({
            name: ['', [Validators.required]],
            email: ['',[Validators.required,Validators.email]],
            password: ['',[Validators.required,Validators.minLength(8)]],
            contactNumber: ['',[Validators.required,Validators.pattern(/^\d{10}$/)]]
      });
  }


  get f() {
    return this.managerForm.controls;
  }

  onRegister() {
     this.submitted = true;

     if(this.managerForm.invalid) {
        return;
     }

     this.adminService.createManager(this.managerForm.value).subscribe({
      next: (data) => {
         console.log(data);
         alert(data);
         this.managerForm.reset;
         this.router.navigate(["/home-admin"]);
      },
      error: (err) => {
        console.error(err);
        alert(err.error.message);
      }
     });


  }


}
