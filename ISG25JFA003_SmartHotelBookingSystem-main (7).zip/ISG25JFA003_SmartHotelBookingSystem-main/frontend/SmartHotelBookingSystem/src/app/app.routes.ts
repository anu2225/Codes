import { Routes } from '@angular/router';
import { Home } from './features/home/home/home';
import { HomeManager } from './features/home/home-manager/home-manager';
import { Login } from './features/auth/login/login';
import { Register } from './features/auth/register/register';
import { WelcomeUser } from './features/user/welcome-user/welcome-user';
import { CreateHotel } from './features/hotel/create-hotel/hotel';
import { GetAllHotelsComponent } from './features/hotel/get-all-hotels/hotel';
import { UpdateHotelComponent } from './features/hotel/update-hotel/hotel';
import { SearchHotelComponent } from './features/hotel/search-hotel/hotel';
import { FilterHotelComponent } from './features/hotel/filter-hotel/hotel';
import { GetHotelByIdComponent } from './features/hotel/get-hotel-by-id/hotel';
import { RoomComponent } from './features/room/get-all-rooms/room';
import { CreateRoomComponent } from './features/room/create-room/room';
import { GetRoomComponent } from './features/room/get-room-by-id/room';
import { UpdateRoomComponent } from './features/room/update-room/room';
import { DeleteRoomComponent } from './features/room/delete-room/room';
import { FilterRoomsComponent } from './features/room/filter-room/room';
import { GetRoomsByHotelComponent } from './features/room/get-room-by-hotel-id/room';
import { CreatePayment } from './features/payment/create-payment/payment';
import { GetAllPayments } from './features/payment/get-all-payments/payment';
import { GetPaymentById } from './features/payment/get-payment-by-booking-id/payment';
import { GetPaymentByBooking } from './features/payment/get-payment-by-id/payment';
import { GetAllBookings } from './features/booking/get-all-bookings/get-all-bookings';
import { GetBookingById } from './features/booking/get-booking-by-id/get-booking-by-id';
import { GetBookingByUser } from './features/booking/get-booking-by-user/get-booking-by-user';
import { CreateBooking } from './features/booking/create-booking/create-booking';
import { AuthGuard } from './core/guards/auth.guard';
import { ManagerGuard } from './core/guards/manager.guard';
import { LoginGuard } from './core/guards/login.guard';
import { RewardHistory } from './features/loyalty/reward-history/reward-history';
import { GetAllReviewsUser } from './features/review/get-all-reviews-user/get-all-reviews-user';
import { HomeAdmin } from './features/home/home-admin/home-admin';
import { AdminGuard } from './core/guards/admin.guard';
import { CreateManagerAccount } from './features/admin/create-manager-account/create-manager-account';
import { PageNotFound } from './features/page-not-found/page-not-found';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: Home , canActivate: [AuthGuard]},
  { path: 'home-manager', component: HomeManager, canActivate: [AuthGuard, ManagerGuard]},
  
  { path: 'login', component: Login, canActivate: [LoginGuard] },
  { path: 'register', component: Register, canActivate: [LoginGuard] },
  { path: 'welcome', component: WelcomeUser },


  //admin
  {path: 'home-admin', component: HomeAdmin, canActivate: [AuthGuard, AdminGuard]},
  {path: 'admin/create-manager', component: CreateManagerAccount, canActivate: [AdminGuard]},

  // Hotel
  { path: 'create-hotel', component: CreateHotel , canActivate: [AuthGuard,ManagerGuard]},
  { path: 'hotels', component: GetAllHotelsComponent , canActivate: [AuthGuard]},
  { path: 'update-hotel/:hotelId', component: UpdateHotelComponent , canActivate: [AuthGuard,ManagerGuard]},
  { path: 'search-hotel', component: SearchHotelComponent , canActivate: [AuthGuard]},
  { path: 'filter-hotel', component: FilterHotelComponent , canActivate: [AuthGuard]},
  { path: 'hotel/:id', component: GetHotelByIdComponent , canActivate: [AuthGuard]},

  // Room
  { path: 'rooms', component: RoomComponent , canActivate: [AuthGuard]},
  { path: 'create-room', component: CreateRoomComponent , canActivate: [AuthGuard,ManagerGuard]},
  { path: 'get-room', component: GetRoomComponent , canActivate: [AuthGuard]},
  { path: 'update-room', component: UpdateRoomComponent , canActivate: [AuthGuard,ManagerGuard]},
  { path: 'delete-room', component: DeleteRoomComponent , canActivate: [AuthGuard,ManagerGuard]},
  { path: 'filter-rooms', component: FilterRoomsComponent , canActivate: [AuthGuard] },
  { path: 'get-rooms-by-hotel', component: GetRoomsByHotelComponent , canActivate: [AuthGuard]},

  // Payment
  { path: 'create-payment/:bookingId/:userId', component: CreatePayment , canActivate: [AuthGuard]},
  {path: 'get-all-payments',component:GetAllPayments},
  {path: 'get-payment-by-id',component:GetPaymentById},
  {path: 'get-payment-by-booking-id',component:GetPaymentByBooking},

  //booking
  {path: 'bookings', component: GetAllBookings, canActivate: [AuthGuard,AdminGuard]},
  {path: 'booking/:id', component: GetBookingById, canActivate: [AuthGuard]},
  // {path: 'booking/user/:userId', component: GetBookingByUser},
  {path: 'bookings/user', component: GetBookingByUser, canActivate: [AuthGuard]},
  {path: 'booking/:id/create-booking', component: CreateBooking, canActivate: [AuthGuard]},

  //reviews
  {path: 'user/:id/reviews', component: GetAllReviewsUser, canActivate: [AuthGuard]},

  //rewards
  {path: 'user/rewards', component: RewardHistory, canActivate: [AuthGuard]},

  { path: '**', component: PageNotFound}
];
