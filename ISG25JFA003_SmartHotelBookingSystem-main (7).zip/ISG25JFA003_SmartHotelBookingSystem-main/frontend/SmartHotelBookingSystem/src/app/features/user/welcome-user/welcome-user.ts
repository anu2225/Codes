import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { User } from '../../../core/services/userService';
import { GetAllManagers } from '../get-all-managers/get-all-managers';
import { GetAllUsers } from '../get-all-users/get-all-users';

@Component({
  selector: 'app-welcome-user',
  standalone: true,
  imports: [CommonModule, GetAllManagers, GetAllUsers],
  templateUrl: './welcome-user.html',
  styleUrl: './welcome-user.css'
})
export class WelcomeUser {
  message: string | undefined;
  isShown = false;

  constructor(private userService: User) {}

  messageShow() {
    this.isShown = true;
    console.log("It is coming");
    this.userService.welcome().subscribe({
    next: (response) => {
      console.log(response);
      this.message = JSON.stringify(response);
    }
   })
  }

  

}
