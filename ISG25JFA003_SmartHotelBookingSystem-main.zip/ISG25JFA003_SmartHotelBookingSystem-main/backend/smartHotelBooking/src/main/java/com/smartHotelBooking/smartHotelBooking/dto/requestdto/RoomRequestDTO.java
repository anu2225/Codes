package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoomRequestDTO {
    private Long roomId;
    private String type;
    private double price;
    private boolean availability;
    private String features;
    private Long hotelId;   // Add केलेलं, कारण Room -> Hotel relation आहे
}

