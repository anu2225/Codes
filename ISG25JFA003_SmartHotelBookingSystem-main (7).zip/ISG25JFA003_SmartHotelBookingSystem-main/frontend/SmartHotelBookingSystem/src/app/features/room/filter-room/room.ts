import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RoomService } from '../../../core/services/roomService';
import { Room } from '../../../core/models/room.model';

@Component({
  selector: 'app-filter-rooms',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './room.html',
  styleUrls: ['./room.css']
})
export class FilterRoomsComponent implements OnInit {
  filterForm!: FormGroup;
  filteredRooms: Room[] = [];
  errorMessage = '';

  constructor(private fb: FormBuilder, private roomService: RoomService) {}

  ngOnInit(): void {
    this.filterForm = this.fb.group({
      minPrice: [''],
      maxPrice: ['']
    });
  }

  filterRooms(): void {
    const min = this.filterForm.value.minPrice;
    const max = this.filterForm.value.maxPrice;

    if (min == null || max == null) {
      this.errorMessage = 'Please enter both min and max price.';
      this.filteredRooms = [];
      return;
    }

    this.roomService.filterRoomsByPrice(min, max).subscribe({
      next: (rooms) => {
        this.filteredRooms = rooms;
        this.errorMessage = '';
      },
      error: () => {
        this.filteredRooms = [];
        this.errorMessage = 'No rooms found for the given price range.';
      }
    });
  }
}

