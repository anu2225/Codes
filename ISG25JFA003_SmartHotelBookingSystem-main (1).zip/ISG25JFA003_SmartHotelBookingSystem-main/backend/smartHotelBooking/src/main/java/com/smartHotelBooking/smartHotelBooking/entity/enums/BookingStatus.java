package com.smartHotelBooking.smartHotelBooking.entity.enums;

public enum BookingStatus {
    Pending,
    Confirmed
}
