package com.smartHotelBooking.smartHotelBooking.controller;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.RoomRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.RoomResponseDTO;
import com.smartHotelBooking.smartHotelBooking.service.RoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService roomService;

    @PostMapping
    public RoomResponseDTO createRoom(@RequestBody RoomRequestDTO roomRequestDTO) {
        return roomService.createRoom(roomRequestDTO);
    }

    @PutMapping("/{id}")
    public RoomResponseDTO updateRoom(@PathVariable Long id, @RequestBody RoomRequestDTO roomRequestDTO) {
        return roomService.updateRoom(id, roomRequestDTO);
    }

    @DeleteMapping("/{id}")
    public void deleteRoom(@PathVariable Long id) {
        roomService.deleteRoom(id);
    }

    @GetMapping("/{id}")
    public RoomResponseDTO getRoomById(@PathVariable Long id) {
        return roomService.getRoomById(id);
    }

    @GetMapping
    public List<RoomResponseDTO> getAllRooms() {
        return roomService.getAllRooms();
    }

    @GetMapping("/hotel/{hotelId}")
    public List<RoomResponseDTO> getRoomsByHotel(@PathVariable Long hotelId) {
        return roomService.getRoomsByHotel(hotelId);
    }

    @GetMapping("/filter")
    public List<RoomResponseDTO> filterByPrice(@RequestParam Double min, @RequestParam Double max) {
        return roomService.filterByPrice(min, max);
    }

    @GetMapping("/available")
    public List<RoomResponseDTO> getAvailableRooms() {
        return roomService.getAvailableRooms();
    }
}