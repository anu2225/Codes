package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.BookingRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.Booking;
import com.smartHotelBooking.smartHotelBooking.entity.User;
import com.smartHotelBooking.smartHotelBooking.repository.BookingRepository;
import com.smartHotelBooking.smartHotelBooking.repository.UserRepository;
import com.smartHotelBooking.smartHotelBooking.service.BookingService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;

    public BookingServiceImpl(BookingRepository bookingRepository, UserRepository userRepository) {
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
    }

    @Override
    public void createBooking(BookingRequestDTO dto) {
        User user = userRepository.findById(dto.getUserId().intValue())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setRoomId(dto.getRoomId());
        booking.setCheckInDate(dto.getCheckInDate());
        booking.setCheckOutDate(dto.getCheckOutDate());
        booking.setBookingDate(dto.getBookingDate());
        booking.setStatus(dto.getStatus());

        bookingRepository.save(booking);
    }

    @Override
    public BookingResponseDTO getBookingById(String bookingId) {
        Booking booking = bookingRepository.findById(Long.parseLong(bookingId))
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        return mapToDTO(booking);
    }

    @Override
    public List<BookingResponseDTO> getBookingsByUserId(String userId) {
        Long userIdLong = Long.parseLong(userId);
        return bookingRepository.findAll().stream()
                .filter(b -> b.getUser().getUserId() == userIdLong)
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void updateBooking(String bookingId, BookingRequestDTO dto) {
        Booking booking = bookingRepository.findById(Long.parseLong(bookingId))
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        User user = userRepository.findById(dto.getUserId().intValue())
                .orElseThrow(() -> new RuntimeException("User not found"));

        booking.setUser(user);
        booking.setRoomId(dto.getRoomId());
        booking.setCheckInDate(dto.getCheckInDate());
        booking.setCheckOutDate(dto.getCheckOutDate());
        booking.setBookingDate(dto.getBookingDate());
        booking.setStatus(dto.getStatus());

        bookingRepository.save(booking);
    }

    @Override
    public void cancelBooking(String bookingId) {
        bookingRepository.deleteById(Long.parseLong(bookingId));
    }

    private BookingResponseDTO mapToDTO(Booking booking) {
        BookingResponseDTO dto = new BookingResponseDTO();
        dto.setBookingId(booking.getBookingId());
        dto.setUserId(booking.getUser().getUserId());
        dto.setRoomId(booking.getRoomId());
        dto.setCheckInDate(booking.getCheckInDate());
        dto.setCheckOutDate(booking.getCheckOutDate());
        dto.setBookingDate(booking.getBookingDate());
        dto.setStatus(booking.getStatus());
        return dto;
    }
}