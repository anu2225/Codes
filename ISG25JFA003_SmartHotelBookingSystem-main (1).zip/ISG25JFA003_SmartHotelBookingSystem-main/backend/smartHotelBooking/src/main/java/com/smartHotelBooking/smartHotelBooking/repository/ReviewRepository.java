package com.smartHotelBooking.smartHotelBooking.repository;

import com.smartHotelBooking.smartHotelBooking.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByHotel_HotelId(Long hotelId);

    List<Review> findByUser_UserId(Long userId);

}
