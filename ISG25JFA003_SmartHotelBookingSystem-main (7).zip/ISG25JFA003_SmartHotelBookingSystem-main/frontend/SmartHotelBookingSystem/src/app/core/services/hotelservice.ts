import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { HttpParams}from'@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HotelService {
  private apiUrl = 'http://localhost:8080/api/hotels';

  constructor(private http: HttpClient) {}

  getHotelList(): Observable<any> {
    return this.http.get(`${this.apiUrl}`);
  }

  getHotelByManager(): Observable<any> {
     return this.http.get(`${this.apiUrl}/manager`);
  }

  // getHotelById(id: number): Observable<any> {
  //   return this.http.get(`${this.apiUrl}/${id}`);
  // }

  createHotel(hotelData: any, token: string): Observable<any> {
    const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });
    return this.http.post(this.apiUrl, hotelData, { headers });
  }
  searchHotels(name: string): Observable<any> {
    const params = new HttpParams().set('location', name);
    return this.http.get(`${this.apiUrl}/search`, { params });
  }


  filterHotelsByRating(minRating: number): Observable<any> {
    // Important: ensure proper param name "minRating" and query string format
    const params = new HttpParams().set('rating', minRating.toString());
    return this.http.get(`${this.apiUrl}/filter`, { params });
  }


 deleteHotel(id: number): Observable<any> {
  return this.http.delete(`${this.apiUrl}/${id}`, {responseType: 'text' });
}


  getHotelById(id: number): Observable<any> {
  return this.http.get<any>(`${this.apiUrl}/${id}`);
}
updateHotel(id: number, hotelData: any): Observable<any> {
  return this.http.put<any>(`${this.apiUrl}/${id}`, hotelData);
}

}
