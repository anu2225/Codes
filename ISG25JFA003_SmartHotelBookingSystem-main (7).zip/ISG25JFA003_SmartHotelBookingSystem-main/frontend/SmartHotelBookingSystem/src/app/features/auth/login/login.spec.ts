import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Login } from './login';
import { ReactiveFormsModule } from '@angular/forms';
import { Auth } from '../../../core/services/authService';
import { Router } from '@angular/router';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { of, throwError } from 'rxjs';

describe('Login Component', () => {
  let component: Login;
  let fixture: ComponentFixture<Login>;
  let authServiceSpy: jasmine.SpyObj<Auth>;

  beforeEach(async () => {
    const authSpy = jasmine.createSpyObj('Auth', ['login', 'setLoggedInState']);

    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule,Login],
      providers: [
        { provide: Auth, useValue: authSpy },
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(Login);
    component = fixture.componentInstance;
    authServiceSpy = TestBed.inject(Auth) as jasmine.SpyObj<Auth>;

    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should invalidate the form if fields are empty', () => {
    component.loginForm.setValue({ email: '', password: '' });
    expect(component.loginForm.invalid).toBeTrue();
  });


  it('should show alert on login error', fakeAsync(() => {
    const errorResponse = { error: { message: 'Invalid credentials' } };

    spyOn(window, 'alert');
    authServiceSpy.login.and.returnValue(throwError(() => errorResponse));

    component.loginForm.setValue({ email: 'user@example.com', password: 'wrongpass' });
    component.onSubmit();
    tick();

    expect(window.alert).toHaveBeenCalledWith('Login failed:');
    expect(component.submitted).toBeFalse();
  }));
});