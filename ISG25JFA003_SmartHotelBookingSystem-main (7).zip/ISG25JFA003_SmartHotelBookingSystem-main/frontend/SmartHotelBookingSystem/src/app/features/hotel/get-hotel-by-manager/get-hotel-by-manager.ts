import { Component, OnInit } from '@angular/core';
import { HotelService } from '../../../core/services/hotelService';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';

@Component({
  selector: 'app-get-hotel-by-manager',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './get-hotel-by-manager.html',
  styleUrl: './get-hotel-by-manager.css'
})
export class GetHotelByManager implements OnInit {

  hotels: any[] = [];
  errorMessage = '';
  deleteMessage:string = '';

 
  constructor(private hotelService: HotelService, private router: Router) {}

    

  ngOnInit(): void {
      console.log("This is calling via ngOnInit");
      this.getHotels();
  }


  getHotels() {
    this.hotelService.getHotelByManager().subscribe({
      next: (data:any[]) => {
        this.hotels = data;
        this.errorMessage = '';
        console.log("THis is calling");
        console.log(this.hotels);
      },
      error: (err) => {
        this.hotels = [];
        this.errorMessage = 'Hotel not found or unauthorized!';
        console.error(err);
      }
    });
  }

  splitAmenities(amenities: string | null | undefined): string[] {
    return (amenities || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 6); // cap to 6 chips for a tidy layout
  }

  viewHotel(id:number) {
    this.router.navigate(["/hotel",id]);
  }

  deleteHotel(hotelId:number) {
    const confirmed = confirm('Are you sure you want to delete this hotel?');
    if(confirmed) {
      this.hotelService.deleteHotel(hotelId).subscribe({
      next: (data) => {
        this.deleteMessage = data;
        this.getHotels();
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = err;
      }
    })
    }
    
  }

  updateHotel(hotelId: number) {
    this.router.navigate([`/update-hotel/${hotelId}`]);
  }

}
