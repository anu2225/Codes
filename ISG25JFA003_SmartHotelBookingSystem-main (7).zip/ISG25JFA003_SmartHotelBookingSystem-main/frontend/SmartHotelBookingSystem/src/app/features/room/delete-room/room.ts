import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RoomService } from '../../../core/services/roomService';

@Component({
  selector: 'app-delete-room',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './room.html',
  styleUrls: ['./room.css']
})
export class DeleteRoomComponent implements OnInit {
  deleteForm!: FormGroup;
  successMessage = '';
  errorMessage = '';

  constructor(private fb: FormBuilder, private roomService: RoomService) {}

  ngOnInit(): void {
    this.deleteForm = this.fb.group({
      roomId: [null, [Validators.required, Validators.min(1)]]
    });
  }

  deleteRoom(): void {
    if (this.deleteForm.valid) {
      const roomId = this.deleteForm.value.roomId;
      this.roomService.deleteRoom(roomId).subscribe({
        next: () => {
          this.successMessage = 'Room deleted successfully!';
          this.errorMessage = '';
          this.deleteForm.reset();
        },
        error: () => {
          this.errorMessage = 'Failed to delete room.';
          this.successMessage = '';
        }
      });
    }
  }
}

