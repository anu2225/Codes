import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // for *ngFor, *ngIf
import { RoomService } from '../../../core/services/roomService';
import { Room } from '../../../core/models/room.model';

@Component({
  selector: 'app-room',
  templateUrl: './room.html',
  styleUrls: ['./room.css'],
  standalone: true,               // optional, if using standalone component
  imports: [CommonModule]
})
export class RoomComponent implements OnInit {

  rooms: Room[] = [];
  hotelSummary: any[] = [];
  hotels: any[] = [];

  constructor(private roomService: RoomService) {}

  ngOnInit(): void {
    this.loadRooms();
    this.loadHotels();
  }

  loadRooms() {
    this.roomService.getRoomList().subscribe({
      next: (res) => {
        this.rooms = res;
        this.generateSummary();
      },
      error: (err) => console.error('Error loading rooms:', err)
    });
  }

  loadHotels() {
    this.roomService.getHotelList().subscribe({
      next: (res) => this.hotels = res,
      error: (err) => console.error('Error loading hotels:', err)
    });
  }

  generateSummary() {
    const summary: any = {};

    this.rooms.forEach(room => {
      const hotelId = room.hotelId;
      const type = room.type;

      if (!summary[hotelId]) summary[hotelId] = {};
      if (!summary[hotelId][type]) summary[hotelId][type] = 0;

      summary[hotelId][type]++;
    });

    this.hotelSummary = Object.keys(summary).map(hotelId => {
      const hotelName = this.hotels.find(h => h.id == +hotelId)?.name || `Hotel ${hotelId}`;
      return {
        hotelId,
        hotelName,
        types: Object.keys(summary[hotelId]).map(type => ({
          type,
          count: summary[hotelId][type]
        }))
      };
    });
  }
}