import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RoomService } from '../../../core/services/roomService';

@Component({
  selector: 'app-create-room',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './room.html',
  styleUrls: ['./room.css']
})
export class CreateRoomComponent implements OnInit {
  roomForm!: FormGroup;
  successMessage = '';
  @Input() hotelId!:number;
  errorMessage = '';

  constructor(private fb: FormBuilder, private roomService: RoomService) {}

  ngOnInit(): void {
    this.roomForm = this.fb.group({
      type: ['', Validators.required],
      price: [null, [Validators.required, Validators.min(1)]],
      availability: [true, Validators.required],
      features: ['', Validators.required],
      roomImage: ['', Validators.required],
      hotelId: [this.hotelId, Validators.required]
    });
  }

  createRoom(): void {
    this.roomForm.patchValue({
      roomImage: String(this.roomForm.value.roomImage).trim()
      });
    if (this.roomForm.valid) {
      this.roomForm.patchValue({ hotelId: this.hotelId });
      console.log(this.roomForm.value);
      this.roomService.createRoom(this.roomForm.value).subscribe({
        next: (data) => {
          console.log(data);
          alert("Room Created Successfully");
          this.successMessage = 'Room created successfully!';
          this.errorMessage = '';
          this.roomForm.reset();
        },
        error: () => {
          this.errorMessage = 'Failed to create room.';
          this.successMessage = '';
        }
      });
    } else {
      this.errorMessage = 'Please fill all required fields.';
      this.successMessage = '';
    }
  }
}

