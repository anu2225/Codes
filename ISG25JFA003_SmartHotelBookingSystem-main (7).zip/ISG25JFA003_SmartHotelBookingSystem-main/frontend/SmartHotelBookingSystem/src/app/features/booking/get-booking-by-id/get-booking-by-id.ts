import { Component, OnInit } from '@angular/core';
import { BookingService } from '../../../core/services/bookingService';
import { ActivatedRoute } from '@angular/router';
import { CommonModule, DatePipe } from '@angular/common';

@Component({
  selector: 'app-get-booking-by-id',
  standalone: true,
  imports: [CommonModule,DatePipe],
  templateUrl: './get-booking-by-id.html',
  styleUrl: './get-booking-by-id.css'
})
export class GetBookingById implements OnInit{
  bookingId!: number;
  booking:any;
  error = '';
     
  constructor(private bookingService: BookingService, private route:ActivatedRoute) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get("id");
      if(id) {
        this.bookingId = +id;
        this.getBooking();
      }
    })
  }

  getBooking() {
      if(!this.bookingId) {
        this.error = "Enter a booking Id";
      }
      this.bookingService.getBooking(this.bookingId).subscribe({
        next: (data) => {
          this.booking = data;
          console.log(data);
        },
        error: (err) => {
          this.booking = null;
          this.error = err;
          console.error("Error",err);
        }
      });
  }

}
