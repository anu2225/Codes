package com.smartHotelBooking.smartHotelBooking.repository;

import com.smartHotelBooking.smartHotelBooking.entity.Redemption;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RedemptionRepository extends JpaRepository<Redemption, Long> {
    List<Redemption> findByUserId(Long userId);
    List<Redemption> findByBookingId(Long bookingId);
}
