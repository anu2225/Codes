import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HotelService } from '../../../core/services/hotelService';

@Component({
  selector: 'app-search-hotel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './hotel.html',
  styleUrls: ['./hotel.css']
})
export class SearchHotelComponent implements OnInit {
  location = '';
  hotels: any[] = [];
  loading = false;
  error = '';

  constructor(private hotelService: HotelService) {}

  ngOnInit(): void {}

  searchHotels() {
    if (!this.location) {
      this.hotels = [];
      return;
    }
    this.loading = true;
    this.hotelService.searchHotels(this.location).subscribe({
      next: (res) => {
        this.hotels = res;
        this.loading = false;
      },
      error: (err) => {
        console.error(err);
        this.error = 'Search failed';
        this.loading = false;
      }
    });
  }
}

