import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RoomService } from '../../../core/services/roomService';
import { Room } from '../../../core/models/room.model';

@Component({
  selector: 'app-get-room',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './room.html',
  styleUrls: ['./room.css']
})
export class GetRoomComponent implements OnInit {
  roomForm!: FormGroup;
  roomDetails: Room | null = null;
  errorMessage = '';

  constructor(private fb: FormBuilder, private roomService: RoomService) {}

  ngOnInit(): void {
    this.roomForm = this.fb.group({
      id: [null, [Validators.required, Validators.min(1)]]
    });
  }

  fetchRoom(): void {
    if (this.roomForm.valid) {
      const roomId = this.roomForm.value.id;
      this.roomService.getRoomById(roomId).subscribe({
        next: (room) => {
          this.roomDetails = room;
          this.errorMessage = '';
        },
        error: () => {
          this.roomDetails = null;
          this.errorMessage = 'Room not found.';
        }
      });
    }
  }
}