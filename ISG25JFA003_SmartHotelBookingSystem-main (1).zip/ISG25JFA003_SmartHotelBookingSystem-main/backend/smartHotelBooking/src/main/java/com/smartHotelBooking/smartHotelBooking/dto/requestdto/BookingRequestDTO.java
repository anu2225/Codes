package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import com.smartHotelBooking.smartHotelBooking.entity.enums.BookingStatus;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

@Data
public class BookingRequestDTO {
//    private Long userId;
    @NotNull
    private Long roomId;
    @NotNull
    private LocalDate checkInDate;
    @NotNull
    private LocalDate checkOutDate;
    @AssertTrue(message = "Check-out date must be after check-in date.")
    public boolean isCheckOutAfterCheckIn() {
        if (checkInDate == null || checkOutDate == null) {
            // Null dates will be handled by @NotNull, so return true here to avoid a redundant error.
            return true;
        }
        return checkOutDate.isAfter(checkInDate);
    }
    private LocalDate bookingDate;
    private BookingStatus status;
}

