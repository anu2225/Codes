import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-get-payment-by-id',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './payment.html',
  styleUrls: ['./payment.css']
})
export class GetPaymentById {
  form: FormGroup;
  payment: any = null;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.form = this.fb.group({
      paymentId: ['', Validators.required]
    });
  }

  fetchPayment() {
    if (this.form.valid) {
      this.http.get(`http://localhost:8080/api/payments/${this.form.value.paymentId}`)
        .subscribe({
          next: res => this.payment = res,
          error: () => alert('❌ Payment not found')
        });
    }
  }}