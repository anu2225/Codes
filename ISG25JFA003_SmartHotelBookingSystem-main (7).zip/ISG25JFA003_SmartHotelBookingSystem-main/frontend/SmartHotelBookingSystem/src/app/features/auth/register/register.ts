import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Auth } from '../../../core/services/authService';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './register.html',
  styleUrl: './register.css'
})
export class Register {
   registerForm: FormGroup;
   submitted = false;
   message: string | undefined;
   private snackBar = inject(MatSnackBar);


   constructor(private fbuilder:FormBuilder, private authService: Auth, private router: Router) {
          this.registerForm = this.fbuilder.group({
            name: ['', [Validators.required]],
            email: ['',[Validators.required,Validators.email]],
            password: ['',[Validators.required,Validators.minLength(8)]],
            contactNumber: ['',[Validators.required,Validators.pattern(/^\d{10}$/)]]
          });
   }

   get f() {
      return this.registerForm.controls;
   }

   onRegister() {
       this.submitted = true;

       if(this.registerForm.invalid) {
          return;
       }

       this.authService.register(this.registerForm.value).subscribe({
        next: (response) => {
           this.message = response;
           alert(this.message);
           this.snackBar.open(`${this.message}`,'',{
              duration: 3000
            });

           this.registerForm.reset();
           this.submitted = false;
           this.router.navigate(["/login"]);
        },
        error: (error) => {
          console.error("Error registering User", error.error);
          alert("Registration Failed");
        }
       });
   }
}
