import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HotelService } from '../../../core/services/hotelService';

@Component({
  selector: 'app-filter-hotel',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './hotel.html',
  styleUrls: ['./hotel.css']
})
export class FilterHotelComponent implements OnInit {
  filterForm!: FormGroup;
  hotels: any[] = [];
  message = '';

  constructor(private fb: FormBuilder, private hotelService: HotelService) {}

  ngOnInit(): void {
    this.filterForm = this.fb.group({
      minRating: ['']
    });
  }

  onFilterByRating(): void {
    const minRating = this.filterForm.value.minRating;
    if (!minRating) return;

    this.hotelService.filterHotelsByRating(minRating).subscribe({
      next: res => {
        this.hotels = res;
        this.message = this.hotels.length === 0 ? 'No hotels found!' : '';
      },
      error: err => {
        console.error(err);
        this.message = 'Error fetching hotels!';
      }
    });
  }
}