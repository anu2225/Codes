import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Auth } from '../../../core/services/authService';
import { HttpClient } from '@angular/common/http';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, RouterModule } from '@angular/router';
import { Role } from '../../../core/models/role';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatButtonModule,RouterModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
   loginForm: FormGroup;
   submitted = false;
   private snackBar = inject(MatSnackBar);

   constructor(private fbuilder: FormBuilder, private authService: Auth, private router: Router) {
        this.loginForm = this.fbuilder.group({
          email: ['',[Validators.required,Validators.email]],
          password: ['',[Validators.required,Validators.minLength(8)]]
        });
   }

   get f() {
      return this.loginForm.controls;
   }

   onSubmit() {
      this.submitted = true;

      if(this.loginForm.invalid) {
        return;
      }

      this.authService.login(this.loginForm.value).subscribe({
        next: (response) => {
          const token = response.token;

          this.authService.setLoggedInState(token);
          const role = this.authService.getUserRole();
          console.log(role);
          
          switch (role) {
              case "ADMIN":
                this.router.navigate(['/home-admin']);
                break;
              case "MANAGER":
                console.log("this is working manager");
                this.router.navigate(['/home-manager']);
                break;
              case "USER":
              default:
                console.log("this is working user");
                this.router.navigate(['/home']);
                break;
            }
        },
      error: (error) => {
            this.loginForm.reset();
            this.submitted = false;
            console.error('Login error:', error.error.message);
            alert('Login failed:');
          }
      });
   }
}
