package com.cognizant.smarthotelbooking.dto.responsedto;

import com.cognizant.smarthotelbooking.entity.enums.BookingStatus;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;

@Data
@AllArgsConstructor
public class BookingRoomResponseDTO {
    private Long bookingId;
    private Long userId;
    private String name;
    private Long roomId;
    private String roomType;
    private String hotelName;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private LocalDate bookingDate;
    private Double paymentAmount;
    private BookingStatus status;
}