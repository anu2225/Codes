package com.cognizant.smarthotelbooking.exception;

public class InvalidPointsException extends RuntimeException {
    public InvalidPointsException(String message) {
        super(message);
    }
}
