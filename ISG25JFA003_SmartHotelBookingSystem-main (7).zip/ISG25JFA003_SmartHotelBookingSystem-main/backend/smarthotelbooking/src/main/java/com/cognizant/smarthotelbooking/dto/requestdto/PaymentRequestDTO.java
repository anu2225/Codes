package com.cognizant.smarthotelbooking.dto.requestdto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;



@Data
public class PaymentRequestDTO {
    @NotNull(message = "Booking Id is required")
    private Long bookingId;
    @NotBlank(message = "Payment Method should not be blank")
    private String paymentMethod;
}
