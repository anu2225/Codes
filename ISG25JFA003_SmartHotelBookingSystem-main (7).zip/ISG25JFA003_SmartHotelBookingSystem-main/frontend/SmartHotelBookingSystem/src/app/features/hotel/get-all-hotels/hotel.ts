// 
// get-all-hotels.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';

// Material
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';

import hotellist from '../get-all-hotels/hotelList';
import { SearchHotelComponent } from '../search-hotel/hotel';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-get-all-hotels',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    NgOptimizedImage,
    FormsModule
  ],
  templateUrl: './hotel.html',
  styleUrls: ['./hotel.css'],
})
export class GetAllHotelsComponent implements OnInit {
  filteredHotels: hotellist[] = [];
  filter:string = '';
  hotels: hotellist[] = [];
  loading = true;
  error = '';
  role = localStorage.getItem('role') || '';
  apiUrl = 'http://localhost:8080/api/hotels';

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.getHotels();
  }

  getHotels() {
    this.loading = true;
    this.error = '';
    this.http.get<hotellist[]>(this.apiUrl).subscribe({
      next: (response) => {
        this.hotels = response || [];
        this.filteredHotels = this.hotels;
        console.log(response);
        this.loading = false;
      },
      error: (err) => {
        console.error('Error fetching hotels:', err);
        this.error = 'Failed to load hotels!';
        this.loading = false;
      },
    });
  }

  editHotel(id: number) {
    if (this.role.toLowerCase() === 'manager') {
      this.router.navigate(['/update-hotel', id]);
    } else {
      alert('Only Manager can update hotels!');
    }
  }

  viewHotel(id:number) {
    this.router.navigate(["/hotel",id]);
  }

  /** Splits a comma-separated amenities string into trimmed items. */
  splitAmenities(amenities: string | null | undefined): string[] {
    return (amenities || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 6); // cap to 6 chips for a tidy layout
  }

  filterHotels(): void {
   console.log("This is getting called");
  const query = this.filter?.toLowerCase().trim() || '';

  if (!query) {
    // If search bar is empty, show all hotels
    this.filteredHotels = this.hotels;
    return;
  }

  this.filteredHotels = this.hotels.filter(hotel =>
    hotel.name.toLowerCase().includes(query) ||
    hotel.location.toLowerCase().includes(query)
  );
}
}