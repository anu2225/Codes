import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginGuard implements CanActivate {

  constructor(private router: Router) {}

  canActivate(): boolean {
    const token = localStorage.getItem('token');

    if (token) {
      // ✅ Token exists, redirect to dashboard or home
      this.router.navigate(['/home']);
      return false;
    }

    // ❌ No token, allow access to login page
    return true;
  }
}
