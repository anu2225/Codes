
package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.config.SecurityConfig;
import com.smartHotelBooking.smartHotelBooking.dto.requestdto.HotelRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.HotelResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.Hotel;
import com.smartHotelBooking.smartHotelBooking.entity.User;
import com.smartHotelBooking.smartHotelBooking.repository.HotelRepository;
import com.smartHotelBooking.smartHotelBooking.repository.UserRepository;
import com.smartHotelBooking.smartHotelBooking.service.HotelService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HotelServiceImpl implements HotelService {

    private final HotelRepository hotelRepository;
    private final UserRepository userRepository;


    @Override
    public HotelResponseDTO createHotel(HotelRequestDTO dto) {
        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));

        Hotel hotel = new Hotel();
        hotel.setName(dto.getName());
        hotel.setLocation(dto.getLocation());
        hotel.setAmenities(dto.getAmenities());
        hotel.setRating(dto.getRating());
        hotel.setManagerId(user.getUserId());
        Hotel saved = hotelRepository.save(hotel);
        return mapToDTO(saved);
    }

    @Override
    public HotelResponseDTO updateHotel(Long id, HotelRequestDTO dto) {
        Hotel hotel = hotelRepository.findById(id).orElseThrow(() -> new RuntimeException("Hotel not found"));
        hotel.setName(dto.getName());
        hotel.setLocation(dto.getLocation());
        hotel.setAmenities(dto.getAmenities());
        hotel.setRating(dto.getRating());
//        hotel.setManagerId(dto.getManagerId());
        Hotel updated = hotelRepository.save(hotel);
        return mapToDTO(updated);
    }

    @Override
    public void deleteHotel(Long id) {
        hotelRepository.deleteById(id);
    }

    @Override
    public HotelResponseDTO getHotelById(Long id) {
        Hotel hotel = hotelRepository.findById(id).orElseThrow(() -> new RuntimeException("Hotel not found"));
        return mapToDTO(hotel);
    }

    @Override
    public List<HotelResponseDTO> getAllHotels() {
        return hotelRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Override
    public List<HotelResponseDTO> searchByLocation(String location) {
        return hotelRepository.findByLocationContainingIgnoreCase(location)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Override
    public List<HotelResponseDTO> filterByRating(Double minRating) {
        return hotelRepository.findByRatingGreaterThanEqual(minRating)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    private HotelResponseDTO mapToDTO(Hotel h) {
        return new HotelResponseDTO(h.getHotelId(), h.getName(), h.getLocation(), h.getAmenities(), h.getRating(), h.getManagerId());
    }
}
