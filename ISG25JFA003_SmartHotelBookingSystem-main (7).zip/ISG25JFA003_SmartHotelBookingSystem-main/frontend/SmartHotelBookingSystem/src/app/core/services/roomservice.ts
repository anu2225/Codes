import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Room } from '../models/room.model';

@Injectable({
  providedIn: 'root'
})
export class RoomService {

  private apiUrl = 'http://localhost:8080/api/rooms';
  private hotelApiUrl = 'http://localhost:8080/api/hotels';

  constructor(private http: HttpClient) {}

  // Get all rooms
  getRoomList(): Observable<Room[]> {
    return this.http.get<Room[]>(`${this.apiUrl}`);
  }

  // Optional: Get all hotels (for mapping hotelId → name)
  getHotelList(): Observable<any[]> {
    return this.http.get<any[]>(`${this.hotelApiUrl}`);
  }
    createRoom(roomData: any): Observable<any> {
  return this.http.post(`${this.apiUrl}`, roomData);
    }
    getRoomById(id: number): Observable<Room> {
  return this.http.get<Room>(`${this.apiUrl}/${id}`);
    }
    updateRoom(id: number, roomData: any): Observable<any> {
  return this.http.put(`${this.apiUrl}/${id}`, roomData);
    
  }
  
deleteRoom(id: number): Observable<any> {
  return this.http.delete(`${this.apiUrl}/${id}`);
}
filterRoomsByPrice(min: number, max: number): Observable<Room[]> {
  const params = new HttpParams()
    .set('min', min.toString())
    .set('max', max.toString());
  return this.http.get<Room[]>(`${this.apiUrl}/filter`, { params });
}
getRoomsByHotelId(hotelId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/hotel/${hotelId}`);
  }
}
