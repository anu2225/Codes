package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.PaymentRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.PaymentResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.Booking;
import com.smartHotelBooking.smartHotelBooking.entity.Payment;
import com.smartHotelBooking.smartHotelBooking.entity.enums.PaymentStatus;
import com.smartHotelBooking.smartHotelBooking.repository.BookingRepository;
import com.smartHotelBooking.smartHotelBooking.repository.PaymentRepository;
import com.smartHotelBooking.smartHotelBooking.service.PaymentService;
import org.springframework.stereotype.Service;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;

    public PaymentServiceImpl(PaymentRepository paymentRepository, BookingRepository bookingRepository) {
        this.paymentRepository = paymentRepository;
        this.bookingRepository = bookingRepository;
    }

    @Override
    public void processPayment(PaymentRequestDTO dto) {
        Booking booking = bookingRepository.findById(dto.getBookingId())
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        Payment payment = new Payment();
        payment.setBooking(booking);
        payment.setUser(booking.getUser()); // assuming user is linked via booking
        payment.setAmount(dto.getAmount());
        payment.setPaymentDate(dto.getPaymentDate());
        payment.setPaymentMethod(dto.getPaymentMethod());
        payment.setPaymentStatus(PaymentStatus.valueOf(dto.getPaymentStatus().toUpperCase()));

        paymentRepository.save(payment);
    }

    @Override
    public PaymentResponseDTO getPaymentById(String paymentId) {
        Payment payment = paymentRepository.findById(Long.parseLong(paymentId))
                .orElseThrow(() -> new RuntimeException("Payment not found"));
        return mapToDTO(payment);
    }

    @Override
    public PaymentResponseDTO getPaymentByBookingId(String bookingId) {
        Long bookingIdLong = Long.parseLong(bookingId);
        return paymentRepository.findAll().stream()
                .filter(p -> p.getBooking().getBookingId().equals(bookingIdLong))
                .findFirst()
                .map(this::mapToDTO)
                .orElseThrow(() -> new RuntimeException("Payment not found for booking"));
    }

    @Override
    public void updatePayment(String paymentId, PaymentRequestDTO dto) {
        Payment payment = paymentRepository.findById(Long.parseLong(paymentId))
                .orElseThrow(() -> new RuntimeException("Payment not found"));

        payment.setAmount(dto.getAmount());
        payment.setPaymentDate(dto.getPaymentDate());
        payment.setPaymentMethod(dto.getPaymentMethod());
        payment.setPaymentStatus(PaymentStatus.valueOf(dto.getPaymentStatus().toUpperCase()));

        paymentRepository.save(payment);
    }

    @Override
    public void deletePayment(String paymentId) {
        paymentRepository.deleteById(Long.parseLong(paymentId));
    }

    private PaymentResponseDTO mapToDTO(Payment payment) {
        PaymentResponseDTO dto = new PaymentResponseDTO();
        dto.setPaymentId(payment.getPaymentId());
        dto.setBookingId(payment.getBooking().getBookingId());
        dto.setAmount(payment.getAmount());
        dto.setPaymentDate(payment.getPaymentDate());
        dto.setPaymentMethod(payment.getPaymentMethod());
        dto.setPaymentStatus(payment.getPaymentStatus().name());
        return dto;
    }
}