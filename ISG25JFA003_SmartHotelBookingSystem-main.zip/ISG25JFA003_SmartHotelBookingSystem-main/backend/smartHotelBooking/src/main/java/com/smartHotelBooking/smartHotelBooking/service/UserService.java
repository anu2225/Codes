package com.smartHotelBooking.smartHotelBooking.service;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.UserRegistrationDTO;
import com.smartHotelBooking.smartHotelBooking.entity.Booking;
import com.smartHotelBooking.smartHotelBooking.entity.Payment;
import com.smartHotelBooking.smartHotelBooking.entity.User;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;

public interface UserService {

    void registerUser(@Valid UserRegistrationDTO user);

    Optional<User> getUserById(int id);

    List<User> getAllUsers();

//    List<Booking> getAllBookings();
//
//    List<Payment> getAllPayments();
}
