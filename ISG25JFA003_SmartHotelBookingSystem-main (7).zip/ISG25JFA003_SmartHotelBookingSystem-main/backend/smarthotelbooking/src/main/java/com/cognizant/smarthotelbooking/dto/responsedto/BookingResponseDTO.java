package com.cognizant.smarthotelbooking.dto.responsedto;

import com.cognizant.smarthotelbooking.entity.enums.BookingStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor; // Add this line

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor // Add this annotation
public class BookingResponseDTO {
    private Long bookingId;
    private long userId;
    private Long roomId;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private LocalDate bookingDate;
    private Double paymentAmount;
    private BookingStatus status;
}