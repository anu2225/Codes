import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { GetAllManagers } from '../../user/get-all-managers/get-all-managers';
import { GetAllUsers } from '../../user/get-all-users/get-all-users';
import { GetAllBookings } from '../../booking/get-all-bookings/get-all-bookings';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-admin',
  standalone: true,
  imports: [CommonModule,GetAllManagers, GetAllUsers, GetAllBookings],
  templateUrl: './home-admin.html',
  styleUrl: './home-admin.css'
})
export class HomeAdmin {

  constructor(private router: Router) {}


  goCreateManager() {
    this.router.navigate(["/admin/create-manager"]);
  }


}
