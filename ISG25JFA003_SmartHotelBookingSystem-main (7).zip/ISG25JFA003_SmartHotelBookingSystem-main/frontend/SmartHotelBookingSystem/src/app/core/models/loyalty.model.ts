export interface LoyaltyPayload {
    bookingId: number;
    points: number;
}