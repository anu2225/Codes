package com.smartHotelBooking.smartHotelBooking.dto.responsedto;

import lombok.Data;

@Data
public class LoyaltyResponseDTO {
    private Long userId;
    private int pointsBalance;
    private String message;
}
