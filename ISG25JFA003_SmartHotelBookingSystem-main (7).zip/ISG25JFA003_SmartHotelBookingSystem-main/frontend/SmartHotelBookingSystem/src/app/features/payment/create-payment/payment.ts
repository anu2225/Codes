import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { LoyaltyService } from '../../../core/services/loyaltyService';
import { GetRewardDetails } from '../../loyalty/get-reward-details/get-reward-details';

@Component({
  selector: 'app-create-payment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule,FormsModule,GetRewardDetails],
  templateUrl: './payment.html',
  styleUrls: ['./payment.css']
})
export class CreatePayment {
  paymentForm: FormGroup;
  bookingId!:number;
  userId!:number;
  points: number = 0;
  message: string = '';
  pointsBalance: number = 0;
  errorMessage = '';

  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router, private route: ActivatedRoute, private loyaltyService: LoyaltyService) {

    this.bookingId = +this.route.snapshot.paramMap.get('bookingId')!;
    this.userId = +this.route.snapshot.paramMap.get('userId')!;


    this.paymentForm = this.fb.group({
      bookingId: [this.bookingId, Validators.required],
      // amount: ['', Validators.required],
      paymentMethod: ['', Validators.required]
    });
  }

  submitPayment() {
    if (this.paymentForm.valid) {
      this.http.post('http://localhost:8080/api/payments/process', this.paymentForm.value)
        .subscribe({
          next: (data:any) => {
            alert('✅ Payment Successful!');
            console.log(data);
            this.router.navigate(["/bookings/user"]);
            // this.router.navigate([`/booking/user/${userId}`]);
            // this.router.navigate(['/get-all-payments']);
          },
          error: () => alert('❌ Payment Failed!')
        });
    } else {
      alert('⚠️ Please fill all fields!');
    }
  }

  redeemPoints() {
      if(this.points <= 0) {
        alert('⚠️ Enter a valid number of points to redeem.');
        return;
      }

      const redeemPayload = {
        bookingId: this.bookingId,
        points: this.points
      };

      this.loyaltyService.redeemRewards(redeemPayload).subscribe({
        next: (data) => {
          alert("Redeem Points successfull");
           this.message = data.message;
           this.pointsBalance = data.pointsBalance;
          //  this.router.navigate([`/booking/${this.bookingId}`]);
        },
        error: (err) => {
          console.error(err.error.message);
          this.errorMessage = err.error.message;
          alert(this.errorMessage);
        }
      })
  }
}