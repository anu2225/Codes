import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { LoyaltyService } from '../../../core/services/loyaltyService';

@Component({
  selector: 'app-get-reward-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './get-reward-details.html',
  styleUrl: './get-reward-details.css'
})
export class GetRewardDetails implements OnInit{
   @Input() userId!:number;
   rewardDetails: any;
   err = '';
   

   constructor(private loyaltyService: LoyaltyService) {}

   ngOnInit(): void {
      this.loyaltyService.getRewardDetails(this.userId).subscribe({
        next: (data) => {
          this.rewardDetails = data;
        },
        error: (err) => {
          console.error = err;
          this.err = "Error Fetching data";
        }
      })
   }

}
