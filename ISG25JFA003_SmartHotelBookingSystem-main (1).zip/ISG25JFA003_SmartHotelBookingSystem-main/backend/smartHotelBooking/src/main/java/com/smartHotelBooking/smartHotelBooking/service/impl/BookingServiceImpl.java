package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.BookingRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingResponseDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingRoomResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.Booking;
import com.smartHotelBooking.smartHotelBooking.entity.Payment;
import com.smartHotelBooking.smartHotelBooking.entity.Room;
import com.smartHotelBooking.smartHotelBooking.entity.User;
import com.smartHotelBooking.smartHotelBooking.entity.enums.BookingStatus;
import com.smartHotelBooking.smartHotelBooking.entity.enums.PaymentStatus;
import com.smartHotelBooking.smartHotelBooking.exception.BookingNotFoundException;
import com.smartHotelBooking.smartHotelBooking.repository.BookingRepository;
import com.smartHotelBooking.smartHotelBooking.repository.PaymentRepository;
import com.smartHotelBooking.smartHotelBooking.repository.RoomRepository;
import com.smartHotelBooking.smartHotelBooking.repository.UserRepository;
import com.smartHotelBooking.smartHotelBooking.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final RoomRepository roomRepository;
    private final PaymentRepository paymentRepository;


    @Override
    public void createBooking(BookingRequestDTO dto) {
        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        User user = userRepository.findByEmail(email).get();

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setRoomId(dto.getRoomId());
        booking.setCheckInDate(dto.getCheckInDate());
        booking.setCheckOutDate(dto.getCheckOutDate());
        booking.setBookingDate(LocalDate.now());
        booking.setStatus(BookingStatus.Pending);
        bookingRepository.save(booking);

        Room room = roomRepository.findById(dto.getRoomId())
                .orElseThrow(() -> new RuntimeException("Room not found"));

        double price = room.getPrice();
        LocalDate checkInDate = booking.getCheckInDate();
        LocalDate checkOutDate = booking.getCheckOutDate();
        double finalPrice = price * checkInDate.until(checkOutDate, ChronoUnit.DAYS);

        Payment payment = new Payment();
        payment.setBooking(booking);
        payment.setUser(booking.getUser());
        payment.setAmount(finalPrice);
        payment.setPaymentDate(LocalDate.now());
        payment.setPaymentStatus(PaymentStatus.Pending);
        paymentRepository.save(payment);
    }

    @Override
    public BookingRoomResponseDTO getBookingById(long bookingId) {
        BookingRoomResponseDTO booking = bookingRepository.findBookingDetailsById(bookingId);
        if(booking == null) {
            throw new BookingNotFoundException("Booking not found");
        }
//        return mapToDTO(booking);
        return booking;
    }

    @Override
    public List<BookingResponseDTO> getBookingsByUserId(long userId) {  //This function is not working correctly and not checked below other methods
        return bookingRepository.findAll().stream()
                .filter(b -> b.getUser().getUserId() == userId)
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void updateBooking(String bookingId, BookingRequestDTO dto) {
        Booking booking = bookingRepository.findById(Long.parseLong(bookingId))
                .orElseThrow(() -> new BookingNotFoundException("Booking not found"));

        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        booking.setCheckInDate(dto.getCheckInDate());
        booking.setCheckOutDate(dto.getCheckOutDate());
        booking.setBookingDate(dto.getBookingDate());
        booking.setStatus(BookingStatus.Pending);

        bookingRepository.save(booking);
    }

    @Override
    public void cancelBooking(String bookingId) {
        Booking booking = bookingRepository.findById(Long.parseLong(bookingId))
                .orElseThrow(() -> new BookingNotFoundException("Booking not found"));

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime bookingTime = booking.getBookingDate().atStartOfDay();

        // Check if more than 24 hours have passed since booking
        if (Duration.between(bookingTime, now).toHours() > 24) {
            throw new RuntimeException("You can only cancel your booking within 24 hours of booking.");
        }

        bookingRepository.deleteById(Long.parseLong(bookingId));
    }

    private BookingResponseDTO mapToDTO(Booking booking) {
        BookingResponseDTO dto = new BookingResponseDTO();
        dto.setBookingId(booking.getBookingId());
        dto.setUserId(booking.getUser().getUserId());
        dto.setRoomId(booking.getRoomId());
        dto.setCheckInDate(booking.getCheckInDate());
        dto.setCheckOutDate(booking.getCheckOutDate());
        dto.setBookingDate(booking.getBookingDate());
        dto.setStatus(booking.getStatus());
        return dto;
    }
}