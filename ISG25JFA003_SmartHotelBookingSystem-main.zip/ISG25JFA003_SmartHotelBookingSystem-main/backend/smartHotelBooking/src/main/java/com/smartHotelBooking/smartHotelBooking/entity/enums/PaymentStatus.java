package com.smartHotelBooking.smartHotelBooking.entity.enums;

public enum PaymentStatus {
    Pending,
    Success
}
