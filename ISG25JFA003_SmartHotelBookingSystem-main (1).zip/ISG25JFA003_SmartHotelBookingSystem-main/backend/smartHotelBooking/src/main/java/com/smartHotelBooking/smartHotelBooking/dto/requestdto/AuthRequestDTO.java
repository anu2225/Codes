package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import lombok.Data;

@Data
public class AuthRequestDTO {
    private String email;
    private String password;
}
