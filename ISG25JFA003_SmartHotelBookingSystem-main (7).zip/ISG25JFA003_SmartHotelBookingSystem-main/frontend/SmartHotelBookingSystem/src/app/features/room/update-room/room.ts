import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RoomService } from '../../../core/services/roomService';
import { Room } from '../../../core/models/room.model';

@Component({
  selector: 'app-update-room',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './room.html',
  styleUrls: ['./room.css']
})
export class UpdateRoomComponent implements OnInit {
  roomForm!: FormGroup;
  successMessage = '';
  errorMessage = '';

  constructor(private fb: FormBuilder, private roomService: RoomService) {}

  ngOnInit(): void {
    this.roomForm = this.fb.group({
      roomId: [null, [Validators.required, Validators.min(1)]],
      type: ['', Validators.required],
      price: [null, [Validators.required, Validators.min(1)]],
      availability: [true, Validators.required],
      features: ['', Validators.required],
      hotelId: [null, Validators.required]
    });
  }

  updateRoom(): void {
    if (this.roomForm.valid) {
      const roomId = this.roomForm.value.roomId;
      const updateData = {
        type: this.roomForm.value.type,
        price: this.roomForm.value.price,
        availability: this.roomForm.value.availability,
        features: this.roomForm.value.features,
        hotelId: this.roomForm.value.hotelId
      };

      this.roomService.updateRoom(roomId, updateData).subscribe({
        next: () => {
          this.successMessage = 'Room updated successfully!';
          this.errorMessage = '';
        },
        error: () => {
          this.errorMessage = 'Failed to update room.';
          this.successMessage = '';
        }
      });
    } else {
      this.errorMessage = 'Please fill all required fields.';
      this.successMessage = '';
    }
  }
}