package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import lombok.Data;

@Data
public class ReviewRequestDTO {
    private Long userId;
    private Long hotelId;
    private double rating;
    private String comment;
}
