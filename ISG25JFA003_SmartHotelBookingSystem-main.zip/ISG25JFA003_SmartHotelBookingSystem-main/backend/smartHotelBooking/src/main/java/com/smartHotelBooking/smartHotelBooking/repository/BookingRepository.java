package com.smartHotelBooking.smartHotelBooking.repository;

import com.smartHotelBooking.smartHotelBooking.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    @Query("SELECT b FROM Booking b JOIN b.user u WHERE u.email = :email")
    List<Booking> findBookingsByUserEmail(String email);
}
