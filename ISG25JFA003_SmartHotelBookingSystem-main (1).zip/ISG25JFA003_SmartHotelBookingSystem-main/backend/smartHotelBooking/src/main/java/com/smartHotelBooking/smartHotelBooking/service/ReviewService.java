package com.smartHotelBooking.smartHotelBooking.service;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.ReviewRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.ReviewResponseDTO;

import java.util.List;

public interface ReviewService {
    ReviewResponseDTO createReview(ReviewRequestDTO dto);
    List<ReviewResponseDTO> getReviewsByHotel(Long hotelId);
    List<ReviewResponseDTO> getReviewsByUser(Long userId);
    ReviewResponseDTO respondToReview(Long reviewId, String response);
    ReviewResponseDTO updateResponse(Long reviewId, String response);
    void deleteReview(Long reviewId);
}
