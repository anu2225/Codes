package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HotelRequestDTO {
    private Long hotelId;        // optional for create
    private String name;
    private String location;
    private String amenities;
    private Double rating;
    private String managerId;
}