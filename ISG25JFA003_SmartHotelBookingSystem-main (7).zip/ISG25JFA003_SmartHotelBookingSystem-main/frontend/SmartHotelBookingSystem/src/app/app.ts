import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

// Features
import { HomeManager } from './features/home/home-manager/home-manager';
import { Login } from './features/auth/login/login';
import { Register } from './features/auth/register/register';
import { WelcomeUser } from './features/user/welcome-user/welcome-user';
import { CreateHotel } from './features/hotel/create-hotel/hotel';
import { GetAllHotelsComponent } from './features/hotel/get-all-hotels/hotel';
import { UpdateHotelComponent } from './features/hotel/update-hotel/hotel';
import { SearchHotelComponent } from './features/hotel/search-hotel/hotel';
import { FilterHotelComponent } from './features/hotel/filter-hotel/hotel';
import { RoomComponent } from './features/room/get-all-rooms/room';
import { CreateRoomComponent } from './features/room/create-room/room';
import { GetRoomComponent } from './features/room/get-room-by-id/room';
import { UpdateRoomComponent } from './features/room/update-room/room';
import { DeleteRoomComponent } from './features/room/delete-room/room';
import { FilterRoomsComponent } from './features/room/filter-room/room';
import { GetRoomsByHotelComponent } from './features/room/get-room-by-hotel-id/room';
import { CreatePayment } from './features/payment/create-payment/payment';
import { GetPaymentById } from './features/payment/get-payment-by-booking-id/payment';
import { GetPaymentByBooking } from './features/payment/get-payment-by-id/payment';
import { GetAllPayments } from './features/payment/get-all-payments/payment';
import { GetHotelByIdComponent } from './features/hotel/get-hotel-by-id/hotel';

import { Home } from './features/home/home/home';
import { Navbar } from './shared/components/navbar/navbar';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatChipsModule } from '@angular/material/chips';
import { GetAllBookings } from './features/booking/get-all-bookings/get-all-bookings';
import { GetBookingById } from './features/booking/get-booking-by-id/get-booking-by-id';
import { GetBookingByUser } from './features/booking/get-booking-by-user/get-booking-by-user';
import { CreateBooking } from './features/booking/create-booking/create-booking';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterOutlet,
    Navbar,
    HomeManager,
    Home,
    HomeManager,
    Register,
    WelcomeUser,
    CreateHotel,
    GetAllHotelsComponent,
    UpdateHotelComponent,
    SearchHotelComponent,
    FilterHotelComponent,
    GetHotelByIdComponent,
    RoomComponent,
    CreateRoomComponent,
    GetRoomComponent,
    UpdateRoomComponent,
    DeleteRoomComponent,
    FilterRoomsComponent,
    GetRoomsByHotelComponent,
    CreatePayment,
    GetAllPayments,
    GetPaymentById,
    GetPaymentByBooking,
    GetHotelByIdComponent,
    GetAllHotelsComponent,
    GetBookingById,
    GetBookingByUser,
    CreateBooking
  ],
  templateUrl: './app.html',
  styleUrls: ['./app.css'],
})
export class App {
  protected readonly title = signal('SmartHotelBookingSystem');
}
