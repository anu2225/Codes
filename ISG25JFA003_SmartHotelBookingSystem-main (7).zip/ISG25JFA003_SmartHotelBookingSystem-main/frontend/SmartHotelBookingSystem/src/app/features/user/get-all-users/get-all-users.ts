import { Component, OnInit } from '@angular/core';
import { User } from '../../../core/services/userService';
import { UserResponse } from '../../../core/models/UserResponse.model';

@Component({
  selector: 'app-get-all-users',
  standalone: true,
  imports: [],
  templateUrl: './get-all-users.html',
  styleUrl: './get-all-users.css'
})
export class GetAllUsers {
  users: UserResponse[] = [];
  isLoading: boolean = false;

  constructor(private userService: User) {}

  getAllUsers() {
    this.isLoading = true;
    this.userService.getAllUsers().subscribe({
      next: (response: UserResponse[]) => {
        this.isLoading = false;
        this.users = response;
      },
      error: (error) => {
        this.isLoading = false;
        console.error("Error fetching users", error);
      }
    });
  }
}
