package com.smartHotelBooking.smartHotelBooking.service;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.PaymentRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.PaymentResponseDTO;

public interface PaymentService {

    void processPayment(PaymentRequestDTO paymentRequest);

    PaymentResponseDTO getPaymentById(String paymentId);

    PaymentResponseDTO getPaymentByBookingId(String bookingId);

    void updatePayment(String paymentId, PaymentRequestDTO updatedPayment);

    void deletePayment(String paymentId);
}