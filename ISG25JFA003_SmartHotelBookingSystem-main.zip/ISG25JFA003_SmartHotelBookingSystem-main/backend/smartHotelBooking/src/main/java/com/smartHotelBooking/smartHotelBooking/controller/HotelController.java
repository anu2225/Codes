package com.smartHotelBooking.smartHotelBooking.controller;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.HotelRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.HotelResponseDTO;
import com.smartHotelBooking.smartHotelBooking.service.HotelService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hotels")
@RequiredArgsConstructor
public class HotelController {

    private final HotelService hotelService;

    @PostMapping
    public ResponseEntity<HotelResponseDTO> createHotel(@RequestBody HotelRequestDTO dto) {
        return ResponseEntity.ok(hotelService.createHotel(dto));
    }

    @GetMapping
    public ResponseEntity<List<HotelResponseDTO>> getAllHotels() {
        return ResponseEntity.ok(hotelService.getAllHotels());
    }

    @GetMapping("/{id}")
    public ResponseEntity<HotelResponseDTO> getHotelById(@PathVariable Long id) {
        return ResponseEntity.ok(hotelService.getHotelById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<HotelResponseDTO> updateHotelById(@PathVariable Long id, @RequestBody HotelRequestDTO dto) {
        return ResponseEntity.ok(hotelService.updateHotel(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteHotel(@PathVariable Long id) {
        hotelService.deleteHotel(id);
        return ResponseEntity.ok("Hotel deleted");
    }

    @GetMapping("/search")
    public ResponseEntity<List<HotelResponseDTO>> searchByLocation(@RequestParam String location) {
        return ResponseEntity.ok(hotelService.searchByLocation(location));
    }

    @GetMapping("/filter")
    public ResponseEntity<List<HotelResponseDTO>> filterByRating(@RequestParam Double rating) {
        return ResponseEntity.ok(hotelService.filterByRating(rating));
    }
}