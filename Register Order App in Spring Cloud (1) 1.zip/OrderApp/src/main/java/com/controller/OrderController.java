package com.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Order;

@RestController
public class OrderController {

	@GetMapping(value="/getDetails")
	public Order getOrderDetails() {
	    Order ord = new Order();
	    ord.setOrderId("O101");
	    ord.setProductName("Mobile");
	    ord.setQuantity(1);
	    ord.setPrice(35678.0);
		return ord;
	}
	
}
