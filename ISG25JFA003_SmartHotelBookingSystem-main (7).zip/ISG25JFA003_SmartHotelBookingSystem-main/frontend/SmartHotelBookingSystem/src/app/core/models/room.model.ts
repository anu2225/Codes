export interface Room {
  roomId?: number;      
  type: string;
  price: number;
  availability: boolean;
  features: string;
  hotelId: number;
}