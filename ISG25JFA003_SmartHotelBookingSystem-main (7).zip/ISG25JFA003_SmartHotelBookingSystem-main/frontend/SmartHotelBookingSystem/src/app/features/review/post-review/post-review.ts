import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ReviewService } from '../../../core/services/reviewService';

@Component({
  selector: 'app-post-review',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './post-review.html',
  styleUrl: './post-review.css'
})
export class PostReview implements OnInit{
  @Input() hotelId!:number;
  reviewForm!: FormGroup;
  isSubmitting = false;
  submissionSuccess = false;
  submissionError = false;

  constructor(private fb: FormBuilder, private reviewService: ReviewService) {}
  ngOnInit(): void {
     this.reviewForm = this.fb.group({
      hotelId: [this.hotelId],
      rating: [0, Validators.required],
      comment: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.reviewForm.invalid) {
      console.log("invalid");
      this.reviewForm.markAllAsTouched();
      return;
    }

    this.isSubmitting = true;
    this.submissionSuccess = false;
    this.submissionError = false;

    this.reviewService.postReview(this.reviewForm.value).subscribe({
      next: () => {
        this.submissionSuccess = true;
        this.isSubmitting = false;
        this.reviewForm.reset();
      },
      error: (error) => {
        console.error('Error posting review:', error);
        this.submissionError = true;
        this.isSubmitting = false;
      }
    });
  }
}
