import { Component, OnInit } from '@angular/core';
import { BookingService } from '../../../core/services/bookingService';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-get-all-bookings',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './get-all-bookings.html',
  styleUrl: './get-all-bookings.css'
})
export class GetAllBookings implements OnInit {

  bookings: any[] = []

  constructor(private bookingService:BookingService, private router: Router) {
     
  }

  ngOnInit(): void {
    this.bookingService.getAllBookings().subscribe({
      next: (data) => {
        console.log(data);
        this.bookings = data;
      },
      error: (err) => {
        console.error("Error Fetching Data", err);
      }
    });
  }

  goBooking(bookingId:number) {
  this.router.navigate([`/booking/${bookingId}`]);
}

}
