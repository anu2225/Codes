import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RoomService } from '../../../core/services/roomService';
import { Router } from '@angular/router';
import { Auth } from '../../../core/services/authService';
import { CreateRoomComponent } from '../create-room/room';

@Component({
  selector: 'app-get-rooms-by-hotel',
  standalone: true,
  imports: [CommonModule, FormsModule, CreateRoomComponent],
  templateUrl: './room.html',
  styleUrls: ['./room.css']
})
export class GetRoomsByHotelComponent implements OnChanges {
  @Input() hotelId!: number;
  rooms: any[] = [];
  errorMessage = '';
  role:string | null; 

  constructor(private roomService: RoomService, private router: Router, private authService: Auth) {
    this.role = this.authService.getRole()
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['hotelId'] && this.hotelId) {
      this.getRooms();
    } else if (changes['hotelId']) {
      // Clear rooms if hotelId becomes null/undefined
      this.rooms = [];
      this.errorMessage = 'Hotel ID not provided.';
    }
  }

  getRooms() {
    this.errorMessage = '';
    if (!this.hotelId) {
      this.errorMessage = 'Please enter a valid hotel ID!';
      this.rooms = [];
      return;
    }

    this.roomService.getRoomsByHotelId(this.hotelId).subscribe({
      next: (data) => {
        this.rooms = data;
        console.log(data);
        this.errorMessage =  data.length === 0 ? 'No rooms found for this hotel.' : '';
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = err.error.message;
        this.rooms = [];
      }
    });
  }

  bookRoom(roomId:number) {
      this.router.navigate([`/booking/${roomId}/create-booking`]);
  }

  deleteRoom(roomId:number) {
    this.roomService.deleteRoom(roomId).subscribe({
      next: () => {
         alert("Room Deleted Successfully");
         this.getRooms();
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = err;
      }
    })
  }
  

}

