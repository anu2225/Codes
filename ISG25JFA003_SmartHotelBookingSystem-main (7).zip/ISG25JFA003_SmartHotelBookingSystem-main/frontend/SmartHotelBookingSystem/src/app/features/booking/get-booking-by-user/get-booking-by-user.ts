import { Component, OnInit } from '@angular/core';
import { BookingService } from '../../../core/services/bookingService';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-get-booking-by-user',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './get-booking-by-user.html',
  styleUrl: './get-booking-by-user.css'
})
export class GetBookingByUser implements OnInit{
  // userId!:number;
  bookings:any = [];
  error = '';
  canCancel: boolean = true;
  
   
  constructor(private bookingService: BookingService, private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {

    this.getBookingByUser();  
    // this.route.paramMap.subscribe(params => {
    //   const id = params.get("userId");
    //   if(id) {
    //     this.userId = +id;
    //     this.getBookingByUser();
    //   }
    // })
  }

  getBookingByUser() {
      this.bookingService.getBookingsByUser().subscribe({
        next: (data) => {
          this.bookings = data;
          console.log(data);
        },
        error: (err) => {
          this.error = err;
          this.bookings = [];
        }
      });
  }


  cancelBooking(bookingId: number) {
    console.log("This is clicking");
      this.bookingService.deleteBooking(bookingId).subscribe({
        next: (data) => {
          console.log(data);
          this.getBookingByUser();
        },
        error: (err) => {
          console.error(err);
          this.error = err;
        }
      })
  }

 
isCancelBookingValid(bookingDate: Date): boolean {
  const now = new Date();
  const booking = new Date(bookingDate);

  // Calculate time difference in milliseconds
  const diffMs = now.getTime() - booking.getTime();

  // 24 hours in milliseconds
  const twentyFourHoursMs = 24 * 60 * 60 * 1000;

  // If more than 24 hours have passed, cancellation is not allowed
  return diffMs >= twentyFourHoursMs;

  
}

goBooking(bookingId:number) {
  this.router.navigate([`/booking/${bookingId}`]);
}

goRewards() {
  this.router.navigate(["/user/rewards"]);
}

}
