package com.smartHotelBooking.smartHotelBooking.controller;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.BookingRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingResponseDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingRoomResponseDTO;
import com.smartHotelBooking.smartHotelBooking.service.BookingService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@Slf4j
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping("/create")
    public ResponseEntity<String> createBooking(@Valid @RequestBody BookingRequestDTO bookingRequest) {
//        log.info("Creating booking for user ID: {}", bookingRequest.getUserId());
        bookingService.createBooking(bookingRequest);
        return ResponseEntity.ok("Booking created successfully.");
    }

    @GetMapping("/{bookingId}")
    public ResponseEntity<BookingRoomResponseDTO> getBooking(@PathVariable long bookingId) {
        log.info("Fetching booking with ID: {}", bookingId);
        BookingRoomResponseDTO booking = bookingService.getBookingById(bookingId);
        return ResponseEntity.ok(booking);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BookingResponseDTO>> getBookingsByUser(@PathVariable long userId) {
        log.info("Fetching all bookings for user ID: {}", userId);
        List<BookingResponseDTO> bookings = bookingService.getBookingsByUserId(userId);
        return ResponseEntity.ok(bookings);
    }

    @PutMapping("/{bookingId}")
    public ResponseEntity<String> updateBooking(@PathVariable String bookingId,
                                                @Valid @RequestBody BookingRequestDTO updatedBooking) {
        log.info("Updating booking ID: {}", bookingId);
        bookingService.updateBooking(bookingId, updatedBooking);
        return ResponseEntity.ok("Booking updated successfully.");
    }

    @DeleteMapping("/{bookingId}")
    public ResponseEntity<String> cancelBooking(@PathVariable String bookingId) {
        log.info("Cancelling booking ID: {}", bookingId);
        bookingService.cancelBooking(bookingId);
        return ResponseEntity.ok("Booking cancelled successfully.");
    }
}
