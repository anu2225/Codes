package com.smartHotelBooking.smartHotelBooking.controller;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.ReviewRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.ReviewResponseDTO;
import com.smartHotelBooking.smartHotelBooking.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    // User Action: Submit a review (requires booking verification)
    @PostMapping
    public ResponseEntity<ReviewResponseDTO> submitReview(@RequestBody ReviewRequestDTO dto) {
        return ResponseEntity.ok(reviewService.createReview(dto));
    }

    // User Action: Get all reviews for a specific hotel
    @GetMapping("/hotel/{hotelId}")
    public ResponseEntity<List<ReviewResponseDTO>> getReviewsByHotel(@PathVariable Long hotelId) {
        return ResponseEntity.ok(reviewService.getReviewsByHotel(hotelId));
    }

    // User Action: Get all reviews submitted by a specific user
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<ReviewResponseDTO>> getReviewsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(reviewService.getReviewsByUser(userId));
    }

    // Hotel Manager Action: Respond to a review
    @PostMapping("/{reviewId}/response")
    public ResponseEntity<ReviewResponseDTO> respondToReview(@PathVariable Long reviewId, @RequestBody String response) {
        return ResponseEntity.ok(reviewService.respondToReview(reviewId, response));
    }

    // Hotel Manager Action: Update a previously submitted response
    @PutMapping("/{reviewId}/response")
    public ResponseEntity<ReviewResponseDTO> updateResponse(@PathVariable Long reviewId, @RequestBody String response) {
        return ResponseEntity.ok(reviewService.updateResponse(reviewId, response));
    }

    // Hotel Manager Action: Delete inappropriate or flagged reviews
    @DeleteMapping("/{reviewId}")
    public ResponseEntity<String> deleteReview(@PathVariable Long reviewId) {
        reviewService.deleteReview(reviewId);
        return ResponseEntity.ok("Review deleted successfully");
    }
}
