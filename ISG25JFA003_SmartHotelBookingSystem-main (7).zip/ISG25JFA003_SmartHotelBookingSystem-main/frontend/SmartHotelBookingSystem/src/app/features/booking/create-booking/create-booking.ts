import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { BookingService } from '../../../core/services/bookingService';
import { ActivatedRoute, Router } from '@angular/router';
import { checkInBeforeCheckOutValidator } from '../../../core/validators/date-range.validator';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';

@Component({
  selector: 'app-create-booking',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule,MatFormFieldModule, MatInputModule, MatButtonModule, MatDatepickerModule],
  templateUrl: './create-booking.html',
  styleUrl: './create-booking.css'
})
export class CreateBooking implements OnInit {
 
  bookingForm:FormGroup;
  submitted = false;
  success = false;
  roomId!:number;
  bookingData:any;
  openModal = false;
  minDate:string = '';

  constructor(private bookingService: BookingService,private fBuilder:FormBuilder, private router: Router, private route: ActivatedRoute) {

    const today = new Date();
    this.minDate = today.toISOString().split('T')[0];
    console.log(this.minDate);

     this.route.paramMap.subscribe(params => {
      const id = params.get("id");
      if(id) {
        this.roomId = +id;
        console.log(this.roomId);
      }
    });
    
    this.bookingForm = this.fBuilder.group({
      roomId: [this.roomId, [Validators.required]],
      checkInDate: [null, [Validators.required]],
      checkOutDate: [null, Validators.required]
    },
    { validators: checkInBeforeCheckOutValidator() }
  );

  


  }

  ngOnInit(): void {
    
  
  }

  get f() {
      return this.bookingForm.controls;
   }

   onSubmit() {
    console.log("button is clicked");
    this.submitted = true;
    if(this.bookingForm.invalid) {
      console.log("Error coming");
      return;
    }

    this.bookingService.createBooking(this.bookingForm.value).subscribe({
      next: (data) => {
         console.log(data);
         console.log("Booking Initiated");
         this.bookingData = data;
         this.success = true;
         this.openModal = true;
      },
      error: (err) => {
        console.log("Error booking", err);
        this.success = false;
      }
    })
   }

   closeModal() {
    this.openModal = false;
   }

   goPay() {
    this.router.navigate(["/create-payment", this.bookingData.bookingId, this.bookingData.userId]);
   }



}
