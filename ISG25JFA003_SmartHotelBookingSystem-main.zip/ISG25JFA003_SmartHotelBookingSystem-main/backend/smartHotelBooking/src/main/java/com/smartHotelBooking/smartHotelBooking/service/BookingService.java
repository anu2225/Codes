package com.smartHotelBooking.smartHotelBooking.service;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.BookingRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingResponseDTO;

import java.util.List;

public interface BookingService {

    void createBooking(BookingRequestDTO bookingRequest);

    BookingResponseDTO getBookingById(String bookingId);

    List<BookingResponseDTO> getBookingsByUserId(String userId);

    void updateBooking(String bookingId, BookingRequestDTO updatedBooking);

    void cancelBooking(String bookingId);
}